package com.shruti.findit.data;

public interface OnResultListener<T> {
    void onResult(T result);
}
