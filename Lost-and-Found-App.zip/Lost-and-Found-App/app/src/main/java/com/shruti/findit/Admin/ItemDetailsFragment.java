package com.shruti.findit.Admin;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.shruti.findit.R;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;

public class ItemDetailsFragment extends Fragment {

    private ImageView imageView;
    private TextView name, category, date, time, location, description, owner;
    private LostItem lostItem;
    private FoundItem foundItem;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_item_details, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        imageView = view.findViewById(R.id.itemImage);
        name = view.findViewById(R.id.itemName);
        category = view.findViewById(R.id.itemCategory);
        date = view.findViewById(R.id.itemDate);
        time = view.findViewById(R.id.itemTime);
        location = view.findViewById(R.id.itemLocation);
        description = view.findViewById(R.id.itemDescription);
        owner = view.findViewById(R.id.itemOwner);
        if (getArguments() != null) {
            if (getArguments().containsKey("lostItem")) {
                lostItem = (LostItem) getArguments().getSerializable("lostItem");
                if (lostItem != null) populateLostItemDetails(lostItem);
            } else if (getArguments().containsKey("foundItem")) {
                foundItem = (FoundItem) getArguments().getSerializable("foundItem");
                if (foundItem != null) populateFoundItemDetails(foundItem);
            }
        }


    }

    private void populateLostItemDetails(LostItem item) {
        name.setText(item.getItemName());
        category.setText(item.getCategory());
        date.setText(item.getDateLost());
        location.setText(item.getLocation());
        time.setText(item.getTimeLost());
        description.setText(item.getDescription());
        owner.setText(item.getOwnerName());
        String imageUrl = item.getImageURL();
        if (imageUrl != null && !imageUrl.startsWith("http")) {
            imageUrl = "http://10.0.2.2/findit_api/" + imageUrl;
            Glide.with(this).load(imageUrl).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.sample_img);
        }
    }
    private void populateFoundItemDetails(FoundItem item) {
        name.setText(item.getItemName());
        category.setText(item.getCategory());
        date.setText(item.getDateFound());
        location.setText(item.getLocation());
        time.setText("—");
        description.setText(item.getDescription());
        owner.setText(item.getFinderName());
        String imageUrl = item.getImageURI();
        if (imageUrl != null && !imageUrl.startsWith("http")) {
            imageUrl = "http://10.0.2.2/findit_api/" + imageUrl;

            Glide.with(this).load(imageUrl).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.sample_img);
        }
    }


}
