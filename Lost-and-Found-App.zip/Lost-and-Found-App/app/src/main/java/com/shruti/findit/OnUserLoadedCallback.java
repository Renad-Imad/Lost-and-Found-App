package com.shruti.findit;

import com.shruti.findit.data.local.User;

public interface OnUserLoadedCallback {
    void onUserLoaded(User user);
}
