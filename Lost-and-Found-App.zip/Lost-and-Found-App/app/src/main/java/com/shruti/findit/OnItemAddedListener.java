package com.shruti.findit;

public interface OnItemAddedListener {
    void onItemAdded();
}
