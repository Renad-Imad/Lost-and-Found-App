package com.shruti.findit.api.responses;

import com.shruti.findit.data.local.User;

public class UserResponse {
    private String status;
    private String message;
    private User user;

    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public User getUser() { return user; }
}