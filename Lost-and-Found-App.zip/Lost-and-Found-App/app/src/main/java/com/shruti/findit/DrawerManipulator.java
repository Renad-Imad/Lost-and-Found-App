package com.shruti.findit;

import android.content.Context;
import android.view.View;
import android.widget.TextView;


public class DrawerManipulator {

    public static void updateDrawerHeader(Context context, View headerView) {
        TextView usernameTextView = headerView.findViewById(R.id.usernameTextView);

        Utility.getLoggedInUserAsync(context, user -> {
            if (user != null && user.name != null) {
                usernameTextView.setText("Hello, " + user.name);
            } else {
                usernameTextView.setText("Hello");
            }
        });
    }
}
