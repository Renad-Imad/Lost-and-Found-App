package com.shruti.findit.data;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.LostItemResponse;
import com.shruti.findit.api.responses.SimpleResponse;
import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.data.local.MatchedItem;
import com.shruti.findit.data.local.User;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SyncManager {
    private static final String TAG = "SyncManager";
    private final AppDatabase localDb;
    private final ApiService apiService;
    private final ExecutorService executorService;

    public SyncManager(Context context) {
        localDb = AppDatabase.getInstance(context);
        apiService = ApiClient.getClient().create(ApiService.class);
        executorService = Executors.newSingleThreadExecutor();
    }

    public void syncData() {
        syncUsers();
        syncLostItems();
        syncFoundItems();
        syncMatchedItems();
    }
    private void syncMatchedItems() {
        executorService.execute(() -> {
            List<MatchedItem> unsynced = localDb.matchedItemDao().getUnsyncedMatches();
            for (MatchedItem item : unsynced) {
                Call<SimpleResponse> call = apiService.addMatchedItem(
                        item.lostItemId,
                        item.foundItemId,
                        item.adminId
                );

                call.enqueue(new Callback<SimpleResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<SimpleResponse> call, @NonNull Response<SimpleResponse> response) {
                        if (response.isSuccessful() && response.body().getStatus().equals("success")) {
                            item.isSynced = true;
                            executorService.execute(() -> localDb.matchedItemDao().update(item));
                            Log.d(TAG, "Matched item synced");
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<SimpleResponse> call, @NonNull Throwable t) {
                        Log.e(TAG, "Matched item sync failed", t);
                    }
                });
            }
        });
    }

    private void syncLostItems() {
        executorService.execute(() -> {
            List<LostItem> items = localDb.lostItemDao().getUnsyncedLostItems();
            for (LostItem item : items) {
                Call<LostItemResponse> call = apiService.addLostItem(
                        item.getItemName(),
                        item.getCategory(),
                        item.getDateLost(),
                        item.getTimeLost(),
                        item.getLocation(),
                        item.getDescription(),
                        item.getImageURL(),
                        item.getUserId(),
                        item.getOwnerName(),
                        item.getPhnum(),
                        item.getEmail(),
                        item.getTag()
                );

                call.enqueue(new Callback<LostItemResponse>() {
                    @Override
                    public void onResponse(Call<LostItemResponse> call, Response<LostItemResponse> response) {
                        if (response.isSuccessful() && "success".equals(response.body().getStatus())) {
                            item.setSynced(true);
                            executorService.execute(() -> localDb.lostItemDao().update(item));
                            Log.d(TAG, "Lost Item Synced: " + item.getItemName());
                        }
                    }

                    @Override
                    public void onFailure(Call<LostItemResponse> call, Throwable t) {
                        Log.e(TAG, "Lost Item Sync Failed", t);
                    }
                });
            }
        });
    }
    private void syncFoundItems() {
        executorService.execute(() -> {
            List<FoundItem> items = localDb.foundItemDao().getUnsyncedFoundItems();
            for (FoundItem item : items) {
                Call<SimpleResponse> call = apiService.addFoundItem(
                        item.getItemName(),
                        item.getCategory(),
                        item.getLocation(),
                        item.getDescription(),
                        item.getImageURI(),
                        item.getDateFound(),
                        item.getFinderName(),
                        item.getFinderId(),
                        item.getEmail(),
                        item.getPhnum(),
                        item.getFinderId(),
                        item.getTag()
                );

                call.enqueue(new Callback<SimpleResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<SimpleResponse> call, Response<SimpleResponse> response) {
                        if (response.isSuccessful() && "success".equals(response.body().getStatus())) {
                            item.setSynced(true);
                            executorService.execute(() -> localDb.foundItemDao().update(item));
                            Log.d(TAG, "Found Item Synced: " + item.getItemName());
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<SimpleResponse> call, @NonNull Throwable t) {
                        Log.e(TAG, "Found Item Sync Failed", t);
                    }
                });
            }
        });
    }
    private void syncUsers() {
        executorService.execute(() -> {
            User unsyncedUser = localDb.userDao().getUnsyncedUser();
            if (unsyncedUser != null) {
                Call<SimpleResponse> call = apiService.addUser(
                        unsyncedUser.userId,
                        unsyncedUser.name,
                        unsyncedUser.email,
                        unsyncedUser.phone,
                        unsyncedUser.password,
                        unsyncedUser.userType
                );

                call.enqueue(new Callback<SimpleResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<SimpleResponse> call, Response<SimpleResponse> response) {
                        if (response.isSuccessful() && response.body() != null &&
                                response.body().getStatus().equals("success")) {

                            unsyncedUser.isSynced = true;
                            executorService.execute(() -> localDb.userDao().update(unsyncedUser));

                            Log.d(TAG, "User synced: " + unsyncedUser.name);
                        } else {
                            Log.e(TAG, "User sync failed: " + response.body().getMessage());
                        }
                    }

                    @Override
                    public void onFailure(Call<SimpleResponse> call, Throwable t) {
                        Log.e(TAG, "User sync error", t);
                    }
                });
            }
        });
    }

}

