package com.shruti.findit.data.local;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;


import java.util.List;


@Dao
public interface LostItemDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(LostItem lostItem);

    @Update
    void update(LostItem lostItem);

    @Query("SELECT * FROM lost_items WHERE isSynced = 0")
    List<LostItem> getUnsyncedLostItems();
    @Query("SELECT * FROM lost_items ORDER BY dateLost DESC")
    List<LostItem> getAllLostItems();
    @Query("SELECT * FROM lost_items WHERE id = :itemId LIMIT 1")
    LostItem getItemById(int itemId);
    @androidx.room.Query("DELETE FROM lost_items")
    void clearAll();
    @Query("DELETE FROM lost_items WHERE id = :itemId")
    void deleteById(int itemId);


}
