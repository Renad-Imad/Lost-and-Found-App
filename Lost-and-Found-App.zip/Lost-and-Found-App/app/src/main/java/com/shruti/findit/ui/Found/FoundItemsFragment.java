package com.shruti.findit.ui.Found;

import static android.app.Activity.RESULT_OK;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import com.shruti.findit.MapActivity;
import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.FoundItemRepository;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.utils.Constants;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class FoundItemsFragment extends DialogFragment {
    private FoundItemRepository foundItemRepository;
    private TextView dateEdit;
    private Spinner categorySpinner;
    private ImageView image;
    private Button upload;
    private Uri imageUri;
    private EditText description, location, itemNameField;
    private String date = null;
    private final int REQ_CODE = 1000;
    private FoundItem editingItem = null;
    private OnItemUpdatedListener itemUpdatedListener;

    public void setOnItemUpdatedListener(OnItemUpdatedListener listener) {
        this.itemUpdatedListener = listener;
    }

    public interface OnItemUpdatedListener {
        void onItemUpdated();
    }

    private int mYear, mMonth, mDay;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_found_items, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        itemNameField = view.findViewById(R.id.item_name_edittext_found);
        description = view.findViewById(R.id.description_found);
        location = view.findViewById(R.id.location_found);
        image = view.findViewById(R.id.image_view_found);
        upload = view.findViewById(R.id.uploadImageButton_found);
        dateEdit = view.findViewById(R.id.selectedDateEditText_found);
        categorySpinner = view.findViewById(R.id.categorySpinner_found);
        foundItemRepository = new FoundItemRepository(requireContext());

        ImageButton datePickerButton = view.findViewById(R.id.datePickerButton_found);
        datePickerButton.setOnClickListener(v -> showDatePicker());

        ImageView locationIcon = view.findViewById(R.id.location_open);
        locationIcon.setOnClickListener(v -> startActivityForResult(new Intent(getActivity(), MapActivity.class), 200));

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(requireContext(),
                R.array.categories_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        if (getArguments() != null && getArguments().containsKey("item")) {
            editingItem = (FoundItem) getArguments().getSerializable("item");
            if (editingItem != null) {
                itemNameField.setText(editingItem.getItemName());
                description.setText(editingItem.getDescription());
                location.setText(editingItem.getLocation());
                date = editingItem.getDateFound();
                dateEdit.setText(date);

                if ( editingItem.getImageURI() != null) {
                    imageUri = Uri.parse( editingItem.getImageURI());
                    image.setImageURI(imageUri);
                    image.setVisibility(View.VISIBLE);
                    upload.setText("Image Selected");
                }

                int spinnerPos = adapter.getPosition(editingItem.getCategory());
                if (spinnerPos >= 0) categorySpinner.setSelection(spinnerPos);
            }
        }

        upload.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.READ_MEDIA_IMAGES}, 101);
                    return;
                }
            } else {
                if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
                    return;
                }
            }
            Intent iGallery = new Intent(Intent.ACTION_PICK);
            iGallery.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(iGallery, REQ_CODE);
        });

        Button submitButton = view.findViewById(R.id.submit_button_found);
        submitButton.setOnClickListener(v -> saveOrUpdate());
    }

    private void saveOrUpdate() {
        String itemName = itemNameField.getText().toString().trim();
        String itemDescription = description.getText().toString().trim();
        String itemLocation = location.getText().toString().trim();
        String itemCategory = categorySpinner.getSelectedItem().toString();

        boolean isEditing = (editingItem != null);
        if (!isEditing && (itemName.isEmpty() || itemDescription.isEmpty() || itemLocation.isEmpty() || imageUri == null || date == null || itemCategory.equals("Select Category"))) {
            Utility.showToast(getContext(), "Please fill all fields.");
            return;
        }

        Utility.getLoggedInUserAsync(requireContext(), user -> {
            if (user == null) {
                Utility.showToast(getContext(), "User not logged in!");
                return;
            }

            Runnable saveLogic = () -> {
                if (editingItem != null) {
                    editingItem.setItemName(itemName);
                    editingItem.setDescription(itemDescription);
                    editingItem.setCategory(itemCategory);
                    editingItem.setLocation(itemLocation);
                    if (editingItem.getFinderId() == null) {
                        editingItem.setFinderId(user.userId);
                    }
                    editingItem.setDateFound(formatDate(date));
                    foundItemRepository.updateItem(editingItem, isConnected());
                }
                if (itemUpdatedListener != null) itemUpdatedListener.onItemUpdated();
                dismiss();
            };
           String imagePath = editingItem != null ? Constants.getFullImageUrl(editingItem.getImageURI()) : "";
            if (imageUri != null && (!isEditing || !imageUri.toString().equals(imagePath))) {
                foundItemRepository.uploadImage(imageUri, new FoundItemRepository.ImageUploadCallback() {
                    @Override
                    public void onSuccess(String imageUrl) {
                        if (editingItem != null) {
                            editingItem.setImageURI(imageUrl);
                            saveLogic.run();
                        } else {
                            FoundItem newItem = new FoundItem();
                            newItem.setItemName(itemName);
                            newItem.setCategory(itemCategory);
                            newItem.setDateFound(formatDate(date));
                            newItem.setImageURI(imageUrl);
                            newItem.setLocation(itemLocation);
                            newItem.setDescription(itemDescription);
                            newItem.setEmail(user.email);
                            newItem.setPhnum(user.phone);
                            newItem.setFinderName(user.name);
                            newItem.setFinderId(user.userId);
                            foundItemRepository.insertItem(newItem, isConnected());

                            if (itemUpdatedListener != null) itemUpdatedListener.onItemUpdated();
                            dismiss();
                        }
                    }

                    @Override
                    public void onFailure(String error) {
                        Utility.showToast(getContext(), "Image upload failed: " + error);
                    }
                });
            } else {
                saveLogic.run();
            }
        });
    }


    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                (view, year, monthOfYear, dayOfMonth) -> {
                    mYear = year;
                    mMonth = monthOfYear;
                    mDay = dayOfMonth;
                    updateDateButton();
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    private void updateDateButton() {
        date = mDay + "/" + (mMonth + 1) + "/" + mYear;
        dateEdit.setText(date);
    }

    private String formatDate(String inputDate) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date parsedDate = inputFormat.parse(inputDate);
            return outputFormat.format(parsedDate);
        } catch (Exception e) {
            return inputDate;
        }
    }

    private boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        Network activeNetwork = cm.getActiveNetwork();
        if (activeNetwork == null) return false;
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(activeNetwork);
        return capabilities != null && (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQ_CODE) {
                imageUri = data.getData();
                image.setImageURI(imageUri);
                upload.setText("Image Selected");
            } else if (requestCode == 200) {
                double latitude = data.getDoubleExtra("latitude", 0);
                double longitude = data.getDoubleExtra("longitude", 0);
                location.setText("Lat: " + latitude + ", Lng: " + longitude);
            }
        }
    }
}