package com.shruti.findit.ui.Found;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.shruti.findit.R;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.utils.Constants;

import java.util.List;
import java.util.Locale;

import jp.wasabeef.glide.transformations.BlurTransformation;

public class FoundItemsAdapter extends RecyclerView.Adapter<FoundItemsAdapter.ItemViewHolder> {

    private final Context context;
    private List<FoundItem> itemList;
    private final boolean showDeleteButton;
    private String category;
    private String currentUserId;


    public FoundItemsAdapter(Context context, List<FoundItem> itemList, String category, boolean showDeleteButton) {
        this.context = context;
        this.itemList = itemList;
        this.category = category;
        this.showDeleteButton = showDeleteButton;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setItemList(List<FoundItem> newList) {
        this.itemList = newList;
        notifyDataSetChanged();
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.found_item_card, parent, false);
        return new ItemViewHolder(view);
    }

    public interface OnItemDeleteListener {
        void onDeleteItem(FoundItem item, int position);
    }

    private OnItemDeleteListener deleteListener;

    public void setOnItemDeleteListener(OnItemDeleteListener listener) {
        this.deleteListener = listener;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        FoundItem item = itemList.get(position);

        if (!category.isEmpty() && !item.getCategory().equals(category)) {
            holder.itemView.setVisibility(View.GONE);
            holder.itemView.setLayoutParams(new RecyclerView.LayoutParams(0, 0));
            return;
        }
        String imagePath = Constants.getFullImageUrl(item.getImageURI());

        if ("found".equalsIgnoreCase(item.getTag())
                && (item.getFinderId() != null && !item.getFinderId().equals(currentUserId))) {
            Glide.with(context)
                    .load(R.drawable.sample_profile).apply(RequestOptions.bitmapTransform(new BlurTransformation(25, 3)))
                    .into(holder.itemImageView);

        } else {

            Glide.with(context)
                    .load(imagePath)
                    .error(R.drawable.sample_img)
                    .into(holder.itemImageView);
        }
        holder.itemNameTextView.setText(item.getItemName());
        holder.finderNameTextView.setText(item.getFinderName());
        holder.description.setText(item.getDescription());
        holder.location.setText(item.getLocation());
        holder.date.setText(item.getDateFound());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, FoundDetails.class);
            intent.putExtra("item", item);
            context.startActivity(intent);
        });

        boolean isOwner = item.getFinderId() != null && item.getFinderId().equals(currentUserId);

        if (isOwner) {

            holder.deleteButton.setVisibility(View.VISIBLE);
            holder.editeButton.setVisibility(View.VISIBLE);
            holder.deleteButton.setOnClickListener(v -> {
                new AlertDialog.Builder(context).setMessage("Are you sure you want to delete this item?").setIcon(R.drawable.delete_ico).setPositiveButton("Yes", (dialog, which) -> {
                    if (deleteListener != null) {
                        deleteListener.onDeleteItem(item, position);
                    }
                }).setNegativeButton("No", null).show();
            });
            holder.editeButton.setOnClickListener(v -> {
                openEditDialog(item);
            });

        } else {
            holder.deleteButton.setVisibility(View.GONE);
            holder.editeButton.setVisibility(View.GONE);
        }
    }

    public void setCurrentUserId(String userId) {
        this.currentUserId = userId;
    }

    @Override
    public int getItemCount() {
        return itemList != null ? itemList.size() : 0;
    }

    public void removeItem(int position) {
        if (position >= 0 && position < itemList.size()) {
            itemList.remove(position);
            notifyItemRemoved(position);
        }
    }

    public FoundItem getItem(int position) {
        return itemList.get(position);
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        ImageView itemImageView;
        TextView itemNameTextView, finderNameTextView, description, location, date;
        ImageButton deleteButton, editeButton;
        LinearLayout swipeActions;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImageView = itemView.findViewById(R.id.itemImageView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            finderNameTextView = itemView.findViewById(R.id.finderNameTextView);
            description = itemView.findViewById(R.id.item_description);
            location = itemView.findViewById(R.id.location);
            date = itemView.findViewById(R.id.dateFound);
            editeButton = itemView.findViewById(R.id.editButton_found);
            deleteButton = itemView.findViewById(R.id.deleteButton_found);
            swipeActions = itemView.findViewById(R.id.swipe_actions_found);
        }
    }

    private void openEditDialog(FoundItem item) {
        FoundItemsFragment dialog = new FoundItemsFragment();
        Bundle args = new Bundle();
        args.putSerializable("item", item);
        dialog.setArguments(args);

        dialog.setOnItemUpdatedListener(() -> {
            new Thread(() -> {
                List<FoundItem> updatedList = com.shruti.findit.data.local.AppDatabase.getInstance(context).foundItemDao().getAllFoundItems();
                ((android.app.Activity) context).runOnUiThread(() -> {
                    setItemList(updatedList);
                });
            }).start();
        });

        if (context instanceof androidx.fragment.app.FragmentActivity) {
            dialog.show(((androidx.fragment.app.FragmentActivity) context).getSupportFragmentManager(), "edit_dialog");
        }
    }

}
