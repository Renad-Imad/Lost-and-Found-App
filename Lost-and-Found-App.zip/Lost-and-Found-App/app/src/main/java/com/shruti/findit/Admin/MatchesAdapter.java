package com.shruti.findit.Admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.shruti.findit.R;
import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.SimpleResponse;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.ui.DashBoard.DashBoardViewModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MatchesAdapter extends RecyclerView.Adapter<MatchesAdapter.ViewHolder> {

    private final Context context;
    private final ArrayList<DashBoardViewModel> matches;
    private final LostItem currentLostItem;
    private final FoundItem currentFoundItem;


    public MatchesAdapter(Context context, ArrayList<DashBoardViewModel> matches,
                          LostItem currentLostItem, FoundItem currentFoundItem) {
        this.context = context;
        this.matches = matches;
        this.currentLostItem = currentLostItem;
        this.currentFoundItem = currentFoundItem;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_match_post, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DashBoardViewModel post = matches.get(position);
        holder.itemName.setText(post.getItemName());
        holder.description.setText(post.getDescription());
        holder.ownerName.setText(post.getTag().equals("Lost") ? post.getOwnerName() : post.getFinderName());

        holder.matchButton.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Confirm Match")
                    .setMessage("Are you sure you want to mark this as matched?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        int lostId = post.getTag().equals("Lost") ? post.getLostItem().getId() : currentLostItem.getId();
                        int foundId = post.getTag().equals("Found") ? post.getFoundItem().getId() : currentFoundItem.getId();
                        SharedPreferences prefs = context.getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
                        String adminId = prefs.getString("userId", "default_id");


                        ApiService api = ApiClient.getClient().create(ApiService.class);
                        api.addMatchedItem(lostId, foundId, adminId).enqueue(new Callback<SimpleResponse>() {

                            @Override
                            public void onResponse(@NonNull Call<SimpleResponse> call, @NonNull Response<SimpleResponse> response) {
                                Log.e("NOTIFY", "Response code: " + response.code());
                                Log.e("NOTIFY", "Response body: " + new Gson().toJson(response.body()));
                                if (response.isSuccessful() && response.body() != null &&
                                        "success".equals(response.body().getStatus())) {

                                    holder.matchButton.setEnabled(false);
                                    holder.matchButton.setText("Matched");
                                    Toast.makeText(context, "Matched successfully", Toast.LENGTH_SHORT).show();

                                    if (post.getTag().equals("Found") && currentLostItem != null) {
                                        api.addNotification(
                                                currentLostItem.getUserId(),
                                                "🎉 تم العثور على الشيء المفقود الخاص بك!",
                                                "تمت مطابقة العنصر: " + currentLostItem.getItemName(),
                                                "match"
                                        ).enqueue(new Callback<SimpleResponse>() {
                                            @Override
                                            public void onResponse(@NonNull Call<SimpleResponse> call, @NonNull Response<SimpleResponse> response) {
                                            }

                                            @Override
                                            public void onFailure(@NonNull Call<SimpleResponse> call, @NonNull Throwable t) {

                                            }
                                        });
                                    }


                                    if (post.getTag().equals("Lost") && currentFoundItem != null) {
                                        api.addNotification(
                                                currentFoundItem.getFinderId(),
                                                " تم تحديد صاحب العنصر الذي وجدته",
                                                "العنصر: " + currentFoundItem.getItemName() + " تم مطابقته.",
                                                "match"
                                        ).enqueue(new Callback<SimpleResponse>() {
                                            @Override
                                            public void onResponse(@NonNull Call<SimpleResponse> call, @NonNull Response<SimpleResponse> response) {
                                                Log.e("NOTIFY", "Response code: " + response.code());
                                                Log.e("NOTIFY", "Response body: " + new Gson().toJson(response.body()));
                                            }

                                            @Override
                                            public void onFailure(@NonNull Call<SimpleResponse> call, @NonNull Throwable t) { }
                                        });
                                    }
                                }
                                else {
                                    Toast.makeText(context, "Server error", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(@NonNull Call<SimpleResponse> call, @NonNull Throwable t) {
                                Toast.makeText(context, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    })
                    .setNegativeButton("Cancel", null)
                    .show();

        });


        if ((post.getTag().equals("Lost") && post.getLostItem().getIsMatched() ==1) ||
                (post.getTag().equals("Found") && post.getFoundItem().getIsMatched()==1)) {
            holder.matchButton.setEnabled(false);
            holder.matchButton.setText("Matched");
        }
    }

    @Override
    public int getItemCount() {
        return matches.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, description, ownerName;
        Button matchButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            description = itemView.findViewById(R.id.description);
            ownerName = itemView.findViewById(R.id.owner_name);
            matchButton = itemView.findViewById(R.id.btn_match);
        }
    }
}
