package com.shruti.findit;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.mapbox.geojson.Point;
import com.mapbox.maps.CameraOptions;
import com.mapbox.maps.CameraState;
import com.mapbox.maps.MapView;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapActivity extends AppCompatActivity {
    private MapView mapView;
    private EditText searchLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        mapView = findViewById(R.id.mapView);
        Button confirmBtn = findViewById(R.id.confirmLocationBtn);
        Button cancelBtn = findViewById(R.id.cancelLocationBtn);

        confirmBtn.setOnClickListener(v -> {
            CameraState camera = mapView.getMapboxMap().getCameraState();
            double lat = camera.getCenter().latitude();
            double lng = camera.getCenter().longitude();
            Intent resultIntent = new Intent();
            resultIntent.putExtra("latitude", lat);
            resultIntent.putExtra("longitude", lng);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
        cancelBtn.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
        Button zoomIn = findViewById(R.id.zoomIn);
        Button zoomOut = findViewById(R.id.zoomOut);
        searchLocation = findViewById(R.id.searchLocation);
        ImageView searchButton = findViewById(R.id.searchButton);
        setDefaultLocation();
        zoomIn.setOnClickListener(v -> mapView.getMapboxMap().setCamera(
                new CameraOptions.Builder()
                        .zoom(mapView.getMapboxMap().getCameraState().getZoom() + 1)
                        .build()
        ));
        zoomOut.setOnClickListener(v -> mapView.getMapboxMap().setCamera(
                new CameraOptions.Builder()
                        .zoom(mapView.getMapboxMap().getCameraState().getZoom() - 1)
                        .build()
        ));
        searchLocation.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                String query = searchLocation.getText().toString().trim();
                if (!query.isEmpty()) {
                    searchLocation(query);
                }
                return true;
            }
            return false;
        });
        searchButton.setOnClickListener(v -> {
            String query = searchLocation.getText().toString().trim();
            if (!query.isEmpty()) {
                searchLocation(query);
            } else {
                Toast.makeText(this, "أدخل اسم الموقع للبحث", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void setDefaultLocation() {
        double defaultLat = 24.7136;  // Riyadh Latitude
        double defaultLng = 46.6753;  // Riyadh Longitude

        mapView.getMapboxMap().setCamera(
                new CameraOptions.Builder()
                        .center(Point.fromLngLat(defaultLng, defaultLat))
                        .zoom(10.0)
                        .build()
        );
    }


    private void searchLocation(String location) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocationName(location, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                double latitude = address.getLatitude();
                double longitude = address.getLongitude();

                mapView.getMapboxMap().setCamera(
                        new CameraOptions.Builder()
                                .center(Point.fromLngLat(longitude, latitude))
                                .zoom(12.0)
                                .build()
                );
            } else {
                Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            Toast.makeText(this, "Search error", Toast.LENGTH_SHORT).show();
        }
    }

}
