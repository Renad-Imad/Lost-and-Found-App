package com.shruti.findit.ui.DashBoard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.shruti.findit.R;
import com.shruti.findit.utils.Constants;

import java.util.ArrayList;

import jp.wasabeef.glide.transformations.BlurTransformation;

public class RecyclerRecentFinditAdapter extends RecyclerView.Adapter<RecyclerRecentFinditAdapter.ViewHolder> {
    private Context context;
    private ArrayList<DashBoardViewModel> arr_recent_findit;
    private OnItemClickListener onItemClickListener;
    private String currentUserId;
    public RecyclerRecentFinditAdapter(Context context, ArrayList<DashBoardViewModel> arr_recent_findit) {
        this.arr_recent_findit = arr_recent_findit;
        this.context = context;
    }

    public void setCurrentUserId(String userId) {
        this.currentUserId = userId;
    }

    public interface OnItemClickListener {
        void onItemClick(DashBoardViewModel item);
    }
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recent_findit, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DashBoardViewModel recentItems = arr_recent_findit.get(position);
        String imagePath = Constants.getFullImageUrl(recentItems.getImageURI());
        if ("found".equalsIgnoreCase(recentItems.getTag())
                && (recentItems.getUserId() != null && !recentItems.getUserId().equals(currentUserId))) {
            Glide.with(context)
                    .load(R.drawable.sample_profile).apply(RequestOptions.bitmapTransform(new BlurTransformation(25, 3)))
                    .into(holder.imageURI);

        } else {

            Glide.with(context)
                    .load(imagePath)
                    .error(R.drawable.sample_img)
                    .into(holder.imageURI);
        }


        holder.description.setText(recentItems.getDescription());

        String determine_tag = recentItems.getTag();
        if ("Lost".equalsIgnoreCase(determine_tag)) {
            holder.tag.setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_dark));
            holder.tag.setText("Lost");
            holder.owner_label.setText("Owner:");
            holder.ownerName.setText(recentItems.getOwnerName());
            holder.date.setText(recentItems.getDateLost());
        } else {
            holder.tag.setTextColor(ContextCompat.getColor(context, android.R.color.holo_green_light));
            holder.tag.setText("Found");
            holder.owner_label.setText("Finder:");
            holder.ownerName.setText(recentItems.getFinderName());
            holder.date.setText(recentItems.getDateFound());
        }


        holder.itemView.setOnClickListener(view -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(recentItems);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arr_recent_findit.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView ownerName, description, tag,date,owner_label;
        ImageView imageURI;

        public ViewHolder(View itemView) {
            super(itemView);
            ownerName = itemView.findViewById(R.id.ownerName);
            date = itemView.findViewById(R.id.date);
            description = itemView.findViewById(R.id.description);
            imageURI = itemView.findViewById(R.id.img_findit_recent);
            tag = itemView.findViewById(R.id.tag);
            owner_label = itemView.findViewById(R.id.owner_label);
        }
    }
}
