package com.shruti.findit.ui.DashBoard;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.FoundItemRepository;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.data.local.User;
import com.shruti.findit.databinding.FragmentDashboardBinding;
import com.shruti.findit.ui.Found.FoundDetails;
import com.shruti.findit.ui.Lost.LostDetails;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DashBoardFragment extends Fragment {
    private FragmentDashboardBinding binding;
    private ArrayList<DashBoardViewModel> arr_recent_findit;
    private RecyclerRecentFinditAdapter adapter;
    private LostItemRepository lostRepo;
    private FoundItemRepository foundRepo;

    @SuppressLint("NotifyDataSetChanged")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        RecyclerView recentList = root.findViewById(R.id.recent_lost_found_list);
        arr_recent_findit = new ArrayList<>();
        recentList.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        adapter = new RecyclerRecentFinditAdapter(requireContext(), arr_recent_findit);
        recentList.setAdapter(adapter);

        TextView userName = root.findViewById(R.id.userName);

        Utility.getLoggedInUserAsync(requireContext(), user -> {
            if (user != null) {
                String currentUserId = user.userId;
                adapter.setCurrentUserId(currentUserId);
                userName.setText(user.name != null ? user.name : "Welcome!");

                lostRepo = new LostItemRepository(requireContext());
                foundRepo = new FoundItemRepository(requireContext());

                ExecutorService executor = Executors.newSingleThreadExecutor();
                executor.execute(() -> {
                    List<LostItem> lostItems = lostRepo.getAllItems();
                    List<FoundItem> foundItems = foundRepo.getAllItems();

                    ArrayList<DashBoardViewModel> allItems = new ArrayList<>();

                    for (LostItem lost : lostItems) {
                        allItems.add(new DashBoardViewModel(lost));
                    }

                    for (FoundItem found : foundItems) {
                        allItems.add(new DashBoardViewModel(found));
                    }

                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                    allItems.sort((a, b) -> {
                        try {
                            Date d1 = sdf.parse(a.getDateFound() != null ? a.getDateFound() : a.getDateLost());
                            Date d2 = sdf.parse(b.getDateFound() != null ? b.getDateFound() : b.getDateLost());
                            return Objects.requireNonNull(d2).compareTo(d1);
                        } catch (ParseException e) {
                            return 0;
                        }
                    });

                    List<DashBoardViewModel> latestItems = allItems.size() > 10 ? allItems.subList(0, 10) : allItems;

                    if (isAdded()) {
                        requireActivity().runOnUiThread(() -> {
                            arr_recent_findit.clear();
                            arr_recent_findit.addAll(latestItems);
                            adapter.notifyDataSetChanged();
                        });
                    }
                });
            }
        });

        adapter.setOnItemClickListener(item -> {
            Intent intent;
            if ("lost".equalsIgnoreCase(item.getTag())) {
                intent = new Intent(requireContext(), LostDetails.class);
                intent.putExtra("itemId", item.getItemName());
            } else {
                intent = new Intent(requireContext(), FoundDetails.class);
                intent.putExtra("itemId", item.getItemName());
            }
            startActivity(intent);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

