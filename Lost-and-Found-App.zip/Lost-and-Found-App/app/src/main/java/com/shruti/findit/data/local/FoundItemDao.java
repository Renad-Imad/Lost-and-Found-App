package com.shruti.findit.data.local;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface FoundItemDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(FoundItem foundItem);

    @Query("SELECT * FROM found_items WHERE isSynced = 0")
    List<FoundItem> getUnsyncedFoundItems();

    @Update
    void update(FoundItem foundItem);
    @Query("SELECT * FROM found_items")
    List<FoundItem> getAllFoundItems();
    @Query("SELECT * FROM found_items WHERE id = :id LIMIT 1")
    FoundItem getItemById(int id);

    @Query("SELECT * FROM found_items WHERE category = :category")
    List<FoundItem> getFoundItemsByCategory(String category);

    @Query("SELECT * FROM found_items ORDER BY dateFound DESC")
    List<FoundItem> getAll();

    @Query("DELETE FROM found_items")
    void clearAll();
    @Query("DELETE FROM found_items WHERE id = :itemId")
    void deleteById(int itemId);


}
