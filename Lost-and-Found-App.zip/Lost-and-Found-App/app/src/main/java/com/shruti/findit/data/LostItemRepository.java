package com.shruti.findit.data;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.LostItemResponse;
import com.shruti.findit.api.responses.SimpleResponse;
import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.data.local.LostItemDao;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LostItemRepository {
    private final LostItemDao lostItemDao;
    public final ExecutorService executorService;
    public final ApiService apiService;

    public LostItemRepository(Context context) {
        AppDatabase database = AppDatabase.getInstance(context);
        apiService = ApiClient.getClient().create(ApiService.class);
        lostItemDao = database.lostItemDao();
        executorService = Executors.newSingleThreadExecutor();

    }
    private void uploadItemToServer(LostItem item) {
        if (item != null) {
            Call<LostItemResponse> call = apiService.addLostItem(
                    item.getItemName(),
                    item.getCategory(),
                    item.getDateLost(),
                    item.getTimeLost(),
                    item.getLocation(),
                    item.getDescription(),
                    item.getImageURL(),
                    item.getUserId(),
                    item.getOwnerName(),
                    item.getPhnum(),
                    item.getEmail(),
                    item.getTag()
            );

            call.enqueue(new Callback<LostItemResponse>() {
                @Override
                public void onResponse(Call<LostItemResponse> call, Response<LostItemResponse> response) {
                    Log.e("LostItemRepository", "Raw response: " + response.toString());
                    if (response.body() != null) {
                        Log.e("LostItemRepository", "Response Body JSON: " + new Gson().toJson(response.body()));
                    } else {
                        Log.e("LostItemRepository", "Response Body is NULL");
                    }

                    Log.e("LostItemRepository", "Response " + response.body());
                    if (response.isSuccessful() && response.body() != null &&
                            response.body().getStatus().equals("success")) {

                        item.setSynced(true);
                        executorService.execute(() -> lostItemDao.update(item));
                        Log.d("LostItemRepository", "Item synced to server: " + item.getItemName());
                    } else {
                        Log.e("LostItemRepository", "Failed to sync item: " + item.getItemName() + "The Status :" + response.body());
                    }
                }

                @Override
                public void onFailure(Call<LostItemResponse> call, Throwable t) {
                    Log.e("LostItemRepository", "Network error: " + t.getMessage());
                }
            });
        }
        else
            return;
    }
    public void insertItem(LostItem item, boolean hasInternet) {
        executorService.execute(() -> {
            lostItemDao.insert(item);

            if (hasInternet) {

                uploadItemToServer(item);
                Log.d("LostItemRepository","ADD to Server");
            }
        });
    }
    public void updateItemRemote(LostItem item) {

        ApiService api = ApiClient.getClient().create(ApiService.class);
        Call<SimpleResponse> call = api.updateLostItem(
                item.getId(),
                item.getItemName(),
                item.getCategory(),
                item.getDateLost(),
                item.getTimeLost(),
                item.getLocation(),
                item.getDescription(),
                item.getImageURL(),
                item.getUserId(),
                item.getOwnerName(),
                item.getPhnum(),
                item.getEmail()
        );

        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<SimpleResponse> call, Response<SimpleResponse> response) {
                if (response.isSuccessful() && response.body() != null &&
                        "success".equals(response.body().getStatus())) {

                    item.setSynced(true);
                    executorService.execute(() -> lostItemDao.update(item));
                    Log.d("LOST_ADD","ADD to Server in onResponse");
                } else {
                    Log.e("LostItemRepo", "Failed to update remotely");
                }
            }

            @Override
            public void onFailure(Call<SimpleResponse> call, Throwable t) {
                Log.e("LostItemRepo", "Update failed: " + t.getMessage());
            }
        });
    }

    public void syncLocalData() {
        executorService.execute(() -> {
            List<LostItem> unsyncedItems = lostItemDao.getUnsyncedLostItems();
            for (LostItem item : unsyncedItems) {
                uploadItemToServer(item);
            }
        });
    }
    public List<LostItem> getAllItems() {
        return lostItemDao.getAllLostItems();
    }


    public void getUnsyncedItemsAsync(OnLostItemsLoadedCallback callback) {
        executorService.execute(() -> {
            List<LostItem> items = lostItemDao.getUnsyncedLostItems();
            callback.onItemsLoaded(items);
        });
    }
    public void getAllItemsAsync(OnLostItemsLoadedCallback callback) {
        executorService.execute(() -> {
            List<LostItem> items = lostItemDao.getAllLostItems();
            callback.onItemsLoaded(items);
        });
    }



    public interface OnLostItemsLoadedCallback {
        void onItemsLoaded(List<LostItem> items);
    }

    public void updateItem(LostItem item) {
        executorService.execute(() -> lostItemDao.update(item));
    }
    public void fetchFromServer(OnResultListener<List<LostItem>> listener) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        apiService.getLostItems().enqueue(new Callback<LostItemResponse>() {
            @Override
            public void onResponse(Call<LostItemResponse> call, Response<LostItemResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getStatus().equals("success")) {
                    List<LostItem> items = response.body().getData();
                    executorService.execute(() -> {

                        for (LostItem item : items) {
                            item.setSynced(true);
                            lostItemDao.insert(item);
                        }
                        listener.onResult(items);
                    });
                } else {
                    listener.onResult(new ArrayList<>());
                }
            }

            @Override
            public void onFailure(Call<LostItemResponse> call, Throwable t) {
                listener.onResult(new ArrayList<>());
            }
        });
    }
    public void markAsMatchedRemote(int itemId) {
        apiService.markAsMatched(itemId, "Lost").enqueue(new Callback<SimpleResponse>() {
            @Override
            public void onResponse(@NonNull Call<SimpleResponse> call, @NonNull Response<SimpleResponse> response) {
                Log.e("LostItemRepo", response.message());
                if (response.isSuccessful() && response.body() != null &&
                        response.body().getStatus().equalsIgnoreCase("success")) {
                    executorService.execute(() -> {
                        LostItem item = lostItemDao.getItemById(itemId);
                        if (item != null) {
                            item.setIsMatched(1);
                            lostItemDao.update(item);
                            Log.e("LostItemRepo", "Mark matched success");
                        }
                    });
                } else {
                    Log.e("LostItemRepo", "Mark matched failed");
                }
            }

            @Override
            public void onFailure(Call<SimpleResponse> call, Throwable t) {
                Log.e("LostItemRepo", "Mark matched failed: " + t.getMessage());
            }
        });
    }
    public void deleteItem(LostItem item, DeletionCallback callback) {
        executorService.execute(() -> {
            try {

                lostItemDao.deleteById(item.getId());


                if (item.isSynced()) {
                    deleteFromServer(item.getId(), callback);
                } else {
                    callback.onSuccess();
                }
            } catch (Exception e) {
                callback.onError(e.getMessage());
            }
        });
    }

    private void deleteFromServer(int itemId, DeletionCallback callback) {
        apiService.deleteLostItem(itemId).enqueue(new Callback<SimpleResponse>() {
            @Override
            public void onResponse(@NonNull Call<SimpleResponse> call, @NonNull Response<SimpleResponse> response) {
                if (response.isSuccessful() && response.body() != null &&
                        response.body().getStatus().equals("success")) {
                    callback.onSuccess();
                } else {
                    callback.onError("Server deletion failed");
                }
            }

            @Override
            public void onFailure(@NonNull Call<SimpleResponse> call, @NonNull Throwable t) {
                callback.onError("Network error: " + t.getMessage());
            }
        });
    }
    public interface DeletionCallback {
        void onSuccess();
        void onError(String error);
    }
}
