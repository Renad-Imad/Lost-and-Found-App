package com.shruti.findit.Admin;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.FoundItemRepository;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.ui.DashBoard.DashBoardViewModel;

import java.util.ArrayList;

public class AdminHomeFragment extends Fragment {

    private TextView adminUserName;
    private AdminPostsAdapter adapter;
    private final ArrayList<DashBoardViewModel> posts = new ArrayList<>();

    private LostItemRepository lostRepo;
    private FoundItemRepository foundRepo;

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_home, container, false);

        adminUserName = view.findViewById(R.id.adminUserName);
        RecyclerView recyclerView = view.findViewById(R.id.recent_lost_found_list_admin);
        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 2));

        adapter = new AdminPostsAdapter(requireContext(), posts, this::openDetails);
        recyclerView.setAdapter(adapter);

        Utility.getLoggedInUserAsync(requireContext(), user -> {
            if (user != null) {
                adminUserName.setText("Hello, " + user.name);
            }
        });

        lostRepo = new LostItemRepository(requireContext());
        foundRepo = new FoundItemRepository(requireContext());

        fetchFromServerAndDisplay();

        return view;
    }

    @SuppressLint("NotifyDataSetChanged")
    private void fetchFromServerAndDisplay() {
        posts.clear();

        lostRepo.fetchFromServer(lostItems -> {
            for (LostItem lost : lostItems) {
                posts.add(new DashBoardViewModel(lost));
            }
            foundRepo.fetchFromServer(foundItems -> {
                for (FoundItem found : foundItems) {
                    posts.add(new DashBoardViewModel(found));
                }

                requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
            });
        });
    }

    private void openDetails(DashBoardViewModel post) {
        ItemDetailsFragment fragment = new ItemDetailsFragment();
        Bundle bundle = new Bundle();

        if (post.getTag().equalsIgnoreCase("Lost")) {
            bundle.putSerializable("item", post.getLostItem());
        } else {
            bundle.putSerializable("item", post.getFoundItem());
        }

        fragment.setArguments(bundle);
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container_admin, fragment)
                .addToBackStack(null)
                .commit();
    }
}
