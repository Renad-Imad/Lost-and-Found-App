package com.shruti.findit.data.local;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "lost_items")
public class LostItem implements Serializable {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String itemName;
    public String category;
    public String dateLost;
    public String timeLost;
    public String location;
    public String description;
    @ColumnInfo(name = "isMatched")
    private int isMatched = 0;
    public String imageURL;
    public String userId;
    public String ownerName;
    public String phnum;

    public String email;
    private boolean isVerified;

    public boolean isSynced = false;
    private  String tag = "Lost";

    public boolean isSynced() {
        return isSynced;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategory() {
        return category;
    }
    public int getIsMatched() {
        return isMatched;
    }


    public void setIsMatched(int  matched) {
        isMatched = matched;
    }
    public void setCategory(String category) {
        this.category = category;
    }

    public String getDateLost() {
        return dateLost;
    }

    public void setDateLost(String dateLost) {
        this.dateLost = dateLost;
    }

    public String getTimeLost() {
        return timeLost;
    }

    public String getLocation() {
        return location;
    }

    public String getDescription() {
        return description;
    }

    public String getImageURL() {
        return imageURL;
    }

    public boolean isVerified() { return isVerified; }
    public void setVerified(boolean verified) { isVerified = verified; }

    public void setPhnum(String phnum) {
        this.phnum = phnum;
    }

    public String getPhnum() {
        return this.phnum;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getUserId() {
        return userId;
    }

    public void setSynced(boolean synced) {
        isSynced = synced;
    }

    public void setUserId(String userId) {
        this.userId = userId != null ? userId : "N/A";
    }

    public void setEmail(String email) {
        this.email = email != null ? email : "N/A";
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL != null ? imageURL : "";
    }

    public void setDescription(String description) {
        this.description = description != null ? description : "No description available";
    }

    public void setLocation(String location) {
        this.location = location != null ? location : "Location not specified";
    }

    public void setTimeLost(String timeLost) {
        this.timeLost = timeLost != null ? timeLost : "Time not available";
    }

}
