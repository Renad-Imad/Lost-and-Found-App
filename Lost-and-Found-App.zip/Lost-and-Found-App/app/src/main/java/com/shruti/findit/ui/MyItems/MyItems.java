package com.shruti.findit.ui.MyItems;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.data.local.User;
import com.shruti.findit.databinding.FragmentLostBinding;
import com.shruti.findit.ui.Lost.LostItemsAdapter;

import java.util.List;
import java.util.stream.Collectors;

public class MyItems extends Fragment {

    private FragmentLostBinding binding;
    private LostItemsAdapter lostAdapter;
    private RecyclerView lostRecyclerView;
    private FloatingActionButton add;
    private  String userId;
    private TextView filterButton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentLostBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        Utility.getLoggedInUserAsync(requireContext(), user -> {
             userId = user != null ? user.userId : "";
        });

        lostRecyclerView = root.findViewById(R.id.lostRecyclerView);
        add = root.findViewById(R.id.add_lost);
        filterButton = root.findViewById(R.id.filterButton);

        add.setVisibility(View.GONE);
        filterButton.setText("My Findit!");
        filterButton.setTextSize(24);
        LostItemRepository lostRepo = new LostItemRepository(requireContext());
        Utility.getLoggedInUserAsync(requireContext(), user -> {
            userId = user != null ? user.userId : "";

            lostRepo.getAllItemsAsync(allItems -> {
                List<LostItem> myItems = allItems;
                if (!userId.isEmpty()) {
                    myItems = myItems.stream()
                            .filter(item -> userId.equals(item.getUserId()))
                            .collect(Collectors.toList());
                }

                List<LostItem> finalItems = myItems;
                requireActivity().runOnUiThread(() -> {
                    lostRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
                    lostAdapter = new LostItemsAdapter(requireContext(), finalItems, true);
                    lostRecyclerView.setAdapter(lostAdapter);
                });
            });
        });



        return root;
    }
    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onResume() {
        super.onResume();
        if (lostAdapter != null) {
            lostAdapter.notifyDataSetChanged();
        }
    }
}
