package com.shruti.findit.ui.Found;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.local.FoundItem;

import jp.wasabeef.glide.transformations.BlurTransformation;

public class FoundDetails extends AppCompatActivity {

    private ImageView img;
    private TextView title, address, email, dateFound, description, category, finderName;
    String phnum;
    private Button backBtn, callBtn, smsBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.found_details);
        img = findViewById(R.id.img);
        title = findViewById(R.id.title);
        address = findViewById(R.id.address);
        email = findViewById(R.id.mail);
        dateFound = findViewById(R.id.dateFound);
        finderName = findViewById(R.id.finderName);
        description = findViewById(R.id.description);
        category = findViewById(R.id.category);
        backBtn = findViewById(R.id.backBtn);
        callBtn = findViewById(R.id.call);
        smsBtn = findViewById(R.id.sms);
        FoundItem item = (FoundItem) getIntent().getSerializableExtra("item");

        if (item == null) {
            Toast.makeText(this, "No item data found!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        String imageUrl = item.getImageURI();

        Utility.getLoggedInUserAsync(this, user -> {
            if (user != null && item.getFinderId() != null && item.getFinderId().equals(user.userId)) {
                showFullDetails(item);
                if (imageUrl != null && !imageUrl.isEmpty()) {
                    Glide.with(this)
                            .load(imageUrl)
                            .error(R.drawable.sample_img)
                            .into(img);
                }
            } else {
                Glide.with(this)
                        .load(R.drawable.sample_profile)
                        .apply(RequestOptions.bitmapTransform(new BlurTransformation(25, 3)))
                        .into(img);
                showRestrictedDetails(item);
            }
        });
        phnum = item.getPhnum();
        callBtn.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + phnum));
            startActivity(intent);
        });

        smsBtn.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("sms:" + phnum));
            intent.putExtra("sms_body", "Hello, I want to inquire about item you found.");
            startActivity(intent);
        });

        backBtn.setOnClickListener(view -> finish());
    }

    private void showFullDetails(FoundItem item) {
        title.setText(item.getItemName());
        description.setText(item.getDescription());
        address.setText(item.getLocation());
        email.setText(item.getEmail());
        finderName.setText(item.getFinderName());
        category.setText(item.getCategory());
        dateFound.setText(item.getDateFound());
    }

    private void showRestrictedDetails(FoundItem item) {
        title.setText(item.getItemName());
        description.setText(item.getDescription());
        finderName.setText(item.getFinderName());
        dateFound.setText(item.getDateFound());
        address.setVisibility(View.GONE);
        email.setVisibility(View.GONE);
        category.setVisibility(View.GONE);
    }


}
