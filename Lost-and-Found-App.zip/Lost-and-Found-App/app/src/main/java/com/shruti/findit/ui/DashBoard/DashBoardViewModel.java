package com.shruti.findit.ui.DashBoard;

import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;

public class DashBoardViewModel {
    private String imageURI;
    private String category, description, ownerName, finderName, tag, dateLost, dateFound, itemName;
    private LostItem lostItem;
    private FoundItem foundItem;
    private String userId;
    public DashBoardViewModel(LostItem lost) {
        this.lostItem = lost;
        this.imageURI = lost.getImageURL();
        this.category = lost.getCategory();
        this.description = lost.getDescription();
        this.ownerName = lost.getOwnerName();
        this.itemName = lost.getItemName();
        this.dateLost = lost.getDateLost();
        this.tag = "Lost";
    }

    public DashBoardViewModel(FoundItem found) {
        this.foundItem = found;
        this.imageURI = found.getImageURI();
        this.category = found.getCategory();
        this.description = found.getDescription();
        this.finderName = found.getFinderName();
        this.itemName = found.getItemName();
        this.dateFound = found.getDateFound();
        this.userId = found.getFinderId();
        this.tag = "Found";
    }
    public DashBoardViewModel() {}
    public LostItem getLostItem() {
        return lostItem;
    }
    public String getUserId() {
        return userId;
    }
    public FoundItem getFoundItem() {
        return foundItem;
    }

    public String getImageURI() { return imageURI; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public String getOwnerName() { return ownerName; }
    public String getFinderName() { return finderName; }
    public String getTag() { return tag; }
    public String getDateLost() { return dateLost; }
    public String getDateFound() { return dateFound; }
    public String getItemName() { return itemName; }
}
