package com.shruti.findit.ui.Found;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.FoundItemRepository;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.databinding.FragmentFoundBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FoundFragment extends Fragment {

    private FragmentFoundBinding binding;
    private FloatingActionButton addBtn;
    private RecyclerView recyclerView;
    private FoundItemsAdapter adapter;
    private TextView filter;
    private List<FoundItem> foundItems = new ArrayList<>();
    private Spinner categorySpinner;
    private String currentUserId = null;

    private String selectedCategory = "";
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentFoundBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        recyclerView = root.findViewById(R.id.foundRecyclerView);
        addBtn = root.findViewById(R.id.add_found);
        filter = root.findViewById(R.id.filterButton);
        categorySpinner = root.findViewById(R.id.categorySpinner);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new FoundItemsAdapter(requireContext(), new ArrayList<>(), "", false);
        adapter.setOnItemDeleteListener((item, position) -> deleteItem(position));

        Utility.getLoggedInUserAsync(requireContext(), user -> {
            if (user != null) {
                currentUserId = user.userId;
                adapter.setCurrentUserId(user.userId);
            }
        });
        recyclerView.setAdapter(adapter);

        addBtn.setOnClickListener(v -> {
            FoundItemsFragment dialogFragment = new FoundItemsFragment();
            dialogFragment.show(getParentFragmentManager(), "form_dialog");
        });

        filter.setOnClickListener(v -> {
            if (categorySpinner.getVisibility() == View.VISIBLE) {
                categorySpinner.setVisibility(View.GONE);
            } else {
                categorySpinner.setVisibility(View.VISIBLE);
            }
        });

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(getContext(),
                R.array.categories_array, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(spinnerAdapter);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = parent.getItemAtPosition(position).toString();
                setupRecyclerView();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedCategory = "";
                setupRecyclerView();
            }
        });
        syncFromServer();
        setupRecyclerView();
        return root;
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setupRecyclerView() {
        executorService.execute(() -> {
            List<FoundItem> itemList;
            if (selectedCategory.isEmpty() || selectedCategory.equals("Select Category")) {
                itemList = AppDatabase.getInstance(requireContext()).foundItemDao().getAllFoundItems();
            } else {
                itemList = AppDatabase.getInstance(requireContext()).foundItemDao().getFoundItemsByCategory(selectedCategory);
            }

            requireActivity().runOnUiThread(() -> {
                adapter.setItemList(itemList);
                adapter.setCategory(selectedCategory);
                adapter.notifyDataSetChanged();
            });
        });
    }
    private void syncFromServer() {
        FoundItemRepository repository = new FoundItemRepository(requireContext());
        repository.fetchFromServer(items -> {
            if (!isAdded()) return;
            requireActivity().runOnUiThread(this::setupRecyclerView);
        });
    }


    private void deleteItem(int position) {
        if (position < 0 || position >= adapter.getItemCount()) return;

        FoundItem item = adapter.getItem(position);
        if (item == null) return;

        FoundItemRepository repository = new FoundItemRepository(requireContext());
        repository.deleteItem(item, new FoundItemRepository.DeletionFoundCallback() {
            @Override
            public void onSuccess() {
                if (!isAdded()) return;

                requireActivity().runOnUiThread(() -> {
                    setupRecyclerView();
                    Toast.makeText(requireContext(), "Item deleted", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                if (!isAdded()) return;

                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(requireContext(), "Delete failed: " + error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        setupRecyclerView();
    }
}
