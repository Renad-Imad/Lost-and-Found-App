package com.shruti.findit;

import android.content.Context;

import android.content.SharedPreferences;
import android.os.Looper;

import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Handler;

public class Utility {

    public static final String SHARED_PREF_NAME = "loginPrefs";

    public static User getLoggedInUser(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        String userEmail = prefs.getString("userEmail", null);
        if (userEmail != null) {
            return AppDatabase.getInstance(context).userDao().getUserByEmail(userEmail);
        }
        return null;
    }
    public static String getCurrentUserId(Context context) {
        return context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
                .getString("userId", null);
    }

    public static void getLoggedInUserAsync(Context context, OnUserLoadedCallback callback) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            SharedPreferences prefs = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
            String userEmail = prefs.getString("userEmail", null);
            User user = null;
            if (userEmail != null) {
                user = AppDatabase.getInstance(context).userDao().getUserByEmail(userEmail);
            }
            User finalUser = user;
            new Handler(Looper.getMainLooper()).post(() -> callback.onUserLoaded(finalUser));
        });
    }
    public static void isCurrentUserAsync(Context context, String userIdToCheck, OnBooleanResult callback) {
        getLoggedInUserAsync(context, user -> {
            if (user != null && user.userId != null) {
                callback.onResult(user.userId.equals(userIdToCheck));
            } else {
                callback.onResult(false);
            }
        });
    }
    public interface OnBooleanResult {
        void onResult(boolean isSameUser);
    }
    public static void saveLoginSession(Context context, User user) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(Utility.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", true);
        editor.putString("userId", user.userId);
        editor.putString("userType", user.userType);
        editor.putString("userName", user.name);
        editor.putString("userEmail", user.email);
        editor.apply();
    }


    public static void clearLoginSession(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
    }


    public static boolean isUserLoggedIn(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean("isLoggedIn", false);
    }
    public static void showToast(Context context, String message) {
        android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show();
    }

}

