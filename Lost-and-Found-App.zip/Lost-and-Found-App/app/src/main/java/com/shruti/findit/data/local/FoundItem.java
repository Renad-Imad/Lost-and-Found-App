package com.shruti.findit.data.local;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "found_items")
public class FoundItem  implements Serializable {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String description;
    public String category;
    public String location;
    @ColumnInfo(name = "isMatched")
    private int isMatched = 0;

    private String itemName;
    private String finderName;
    private String finderId;
    private String dateFound;
    private String email;

    private String phnum;
    private String imageURI;
    private boolean isVerified;

    private String tag = "Found";

    public boolean isSynced;


    public void setIsMatched(int matched) {
        isMatched = matched;
    }
    public  int getIsMatched(){
        return isMatched;
    }
    public void setId(int id) {
        this.id = id;
    }

    public boolean isSynced() {
        return isSynced;
    }
    public void setFinderName(String finderName) {
        this.finderName = finderName;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public void setSynced(boolean synced) {
        isSynced = synced;
    }

    public String getEmail() {
        return email;
    }

    public String getPhnum() {
        return phnum;
    }

    public void setPhnum(String phnum) {
        this.phnum = phnum;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public String getTag() {
        return tag;
    }
    public void setFinderId(String finderId) {
        this.finderId = finderId;
    }


    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isVerified() { return isVerified; }
    public void setVerified(boolean verified) { isVerified = verified; }

    public String getFinderId() {
        return finderId;
    }

    public int getId() {
        return id;
    }

    public String getDateFound() {
        return dateFound;
    }

    public String getImageURI() {
        return imageURI;
    }

    public void setImageURI(String imageURI) {
        this.imageURI = imageURI;
    }

    public void setDateFound(String dateFound) {
        this.dateFound = dateFound;
    }

    public String getFinderName() {
        return finderName;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
