package com.shruti.findit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.shruti.findit.Admin.AdminDashboardActivity;
import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.UserResponse;
import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {

    EditText loginEmail, loginPassword;
    Button loginButton;
    TextView signupRedirectText;

    AppDatabase localDb;
    ExecutorService executorService;
    ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginEmail = findViewById(R.id.login_email);
        loginPassword = findViewById(R.id.login_password);
        loginButton = findViewById(R.id.login_button);
        signupRedirectText = findViewById(R.id.signupRedirectText);

        localDb = AppDatabase.getInstance(this);
        executorService = Executors.newSingleThreadExecutor();
        apiService = ApiClient.getClient().create(ApiService.class);

        SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
        String userId = sharedPreferences.getString("userId", "");
        String userType = sharedPreferences.getString("userType", null);

        if (isLoggedIn) {
            executorService.execute(() -> {
                User user = localDb.userDao().getUserById(userId);
                runOnUiThread(() -> {
                    if (user != null) {
                        navigateToDashboard(this, userType);
                    }
                });
            });
        }

        loginButton.setOnClickListener(view -> {
            if (!validateEmail() || !validatePassword()) {
                Toast.makeText(Login.this, "Enter data in all fields", Toast.LENGTH_SHORT).show();
            } else {
                checkUser();
            }
        });

        signupRedirectText.setOnClickListener(view -> {
            startActivity(new Intent(Login.this, Register.class));
        });
    }

    private boolean validateEmail() {
        String val = loginEmail.getText().toString().trim();
        if (TextUtils.isEmpty(val)) {
            loginEmail.setError("Email cannot be empty");
            return false;
        } else {
            loginEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String val = loginPassword.getText().toString().trim();
        if (TextUtils.isEmpty(val)) {
            loginPassword.setError("Password cannot be empty");
            return false;
        } else {
            loginPassword.setError(null);
            return true;
        }
    }

    private void checkUser() {
        String email = loginEmail.getText().toString().trim();
        String password = loginPassword.getText().toString().trim();

        if (isConnected()) {
            apiService.loginUser(email, password).enqueue(new Callback<UserResponse>() {
                @Override
                public void onResponse(@NonNull Call<UserResponse> call, @NonNull Response<UserResponse> response) {
                    if (response.isSuccessful() && response.body() != null && response.body().getStatus().equals("success")) {
                        User user = response.body().getUser();
                        if (user.userId == null || user.userId.trim().isEmpty()) {
                            Toast.makeText(Login.this, "Error: Missing userId from server!", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        user.password = password;
                        user.isSynced = true;
                        Utility.clearLoginSession(Login.this);
                        Utility.saveLoginSession(Login.this, user);

                        executorService.execute(() -> localDb.userDao().insert(user));

                        navigateToDashboard(Login.this, user.userType);
                    } else {
                        Toast.makeText(Login.this, "Login failed: Invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(@NonNull Call<UserResponse> call, @NonNull Throwable t) {
                    Toast.makeText(Login.this, "Connection error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            executorService.execute(() -> {
                User user = localDb.userDao().getUserByEmail(email);
                if (user != null && user.password.equals(password)) {
                    Utility.clearLoginSession(Login.this);
                    Utility.saveLoginSession(Login.this, user);

                    runOnUiThread(() -> navigateToDashboard(Login.this, user.userType));
                } else {
                    runOnUiThread(() ->
                            Toast.makeText(Login.this, "Invalid credentials (Offline Mode)", Toast.LENGTH_SHORT).show()
                    );
                }
            });
        }
    }

    private void navigateToDashboard(Context context, String userType) {
        Intent intent;
        if (userType != null && userType.equalsIgnoreCase("admin")) {
            intent = new Intent(context, AdminDashboardActivity.class);
        } else {
            intent = new Intent(context, BindingNavigation.class);
        }
        context.startActivity(intent);
        finish();
    }


    private boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;

        Network network = cm.getActiveNetwork();
        if (network == null) return false;

        NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
        return capabilities != null &&
                (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
    }
}
