package com.shruti.findit.ui.Lost;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.databinding.FragmentLostBinding;

import java.util.ArrayList;
import java.util.List;

public class LostFragment extends Fragment {

    private FragmentLostBinding binding;
    private List<LostItem> itemsList = new ArrayList<>();
    private FloatingActionButton addBtn;
    private RecyclerView recyclerView;
    private LostItemsAdapter adapter;
    private TextView filter;
    private String selectedCategory = "";
    private Spinner categorySpinner;
    private String currentUserId = null;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        LostViewModel lostViewModel = new ViewModelProvider(this).get(LostViewModel.class);
        binding = FragmentLostBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        recyclerView = root.findViewById(R.id.lostRecyclerView);
        addBtn = root.findViewById(R.id.add_lost);
        filter = root.findViewById(R.id.filterButton);
        categorySpinner = root.findViewById(R.id.categorySpinner);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new LostItemsAdapter(requireContext(), new ArrayList<>(), true);
        adapter.setOnItemActionListener(new LostItemsAdapter.OnItemActionListener() {
            @Override
            public void onEdit(int position) {
                handleEditClick(position);
            }

            @Override
            public void onDelete(int position) {
                handleDeleteClick(position);
            }
        });
        recyclerView.setAdapter(adapter);
        Utility.getLoggedInUserAsync(requireContext(), user -> {
            if (user != null) {
                currentUserId = user.userId;
                adapter.setCurrentUserId(user.userId);
                loadLocalData();
            }
        });

        addBtn.setOnClickListener(v -> {
            LostItemsFragment dialogFragment = new LostItemsFragment();
            dialogFragment.show(getParentFragmentManager(), "form_dialog");
            if (isAdded()) {
                requireActivity().runOnUiThread(this::loadLocalData);
            }
        });

        filter.setOnClickListener(v -> {
            if (categorySpinner.getVisibility() == View.VISIBLE) {
                categorySpinner.setVisibility(View.GONE);
            } else {
                categorySpinner.setVisibility(View.VISIBLE);
            }
        });

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(getContext(),
                R.array.categories_array, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(spinnerAdapter);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = parent.getItemAtPosition(position).toString();
                loadLocalData();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedCategory = "";
                loadLocalData();
            }
        });

        syncFromServer();
        return root;
    }

    private void handleEditClick(int position) {
        if (position >= 0 && position < itemsList.size()) {
            LostItem item = itemsList.get(position);

            if (item.getUserId() != null && item.getUserId().equals(currentUserId)) {
                openEditDialog(item);
            } else {
                Toast.makeText(requireContext(), "You can only edit your own post", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void syncFromServer() {
        LostItemRepository repository = new LostItemRepository(requireContext());

        repository.fetchFromServer(items -> {
            if (isAdded() && getActivity() != null) {
                requireActivity().runOnUiThread(this::loadLocalData);
            }
        });

    }


    private void handleDeleteClick(int position) {
        if (position >= 0 && position < itemsList.size()) {
            LostItem item = itemsList.get(position);

            if (item.getUserId() != null && item.getUserId().equals(currentUserId)) {
                showDeleteConfirmationDialog(position);
            } else {
                Toast.makeText(requireContext(), "You can only delete your own post", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void showDeleteConfirmationDialog(int position) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete this item?")
                .setPositiveButton("Delete", (dialog, which) -> deleteItem(position))
                .setNegativeButton("Cancel", null)
                .show();
    }


    private void deleteItem(int position) {
        if (position < 0 || position >= itemsList.size()) return;

        LostItem item = itemsList.get(position);
        LostItemRepository repository = new LostItemRepository(requireContext());

        repository.deleteItem(item, new LostItemRepository.DeletionCallback() {
            @Override
            public void onSuccess() {
                requireActivity().runOnUiThread(() -> {
                    itemsList.remove(position);
                    adapter.removeItem(position);
                    Toast.makeText(requireContext(), "Item deleted", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(requireContext(), "Delete failed: " + error, Toast.LENGTH_SHORT).show());
            }
        });
    }


    private void loadLocalData() {
        LostItemRepository repository = new LostItemRepository(requireContext());
        repository.getAllItemsAsync(items -> {
            requireActivity().runOnUiThread(() -> {
                itemsList.clear();
                itemsList.addAll(items);

                List<LostItem> filteredItems = new ArrayList<>();
                if (!selectedCategory.isEmpty() && !selectedCategory.equals("Select Category")) {
                    for (LostItem item : items) {
                        if (item.getCategory().equals(selectedCategory)) {
                            filteredItems.add(item);
                        }
                    }
                } else {
                    filteredItems.addAll(items);
                }

                adapter.updateList(filteredItems);
            });
        });
    }

    private void openEditDialog(LostItem item) {
        LostItemsFragment dialogFragment = new LostItemsFragment();
        Bundle args = new Bundle();
        args.putSerializable("item", item);
        dialogFragment.setArguments(args);

        dialogFragment.setOnItemAddedListener(() -> {
            loadLocalData();
        });

        dialogFragment.show(getParentFragmentManager(), "edit_dialog");
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onResume() {
        super.onResume();
        loadLocalData();
    }
}
