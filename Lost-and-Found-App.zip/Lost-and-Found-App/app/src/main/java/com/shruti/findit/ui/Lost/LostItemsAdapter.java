package com.shruti.findit.ui.Lost;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shruti.findit.R;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.utils.Constants;

import java.util.List;

public class LostItemsAdapter extends RecyclerView.Adapter<LostItemsAdapter.ItemViewHolder> {
    private final boolean showDeleteButton;
    private final Context context;
    private List<LostItem> lostItemList;
    private String category = "";
    private String currentUserId;


    private int lastSwipedPosition = -1;

    public interface OnItemActionListener {
        void onEdit(int position);
        void onDelete(int position);
    }
    private OnItemActionListener actionListener;

    public void setOnItemActionListener(OnItemActionListener listener) {
        this.actionListener = listener;
    }
    public LostItemsAdapter(Context context, List<LostItem> lostItemList,boolean  showDeleteButton) {
        this.context = context;
        this.lostItemList = lostItemList;
        this.showDeleteButton = showDeleteButton;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setLostItemList(List<LostItem> list) {
        this.lostItemList = list;
        notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setCategory(String category) {
        this.category = category;
        notifyDataSetChanged();
    }
    public void setCurrentUserId(String userId) {
        this.currentUserId = userId;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lost_item_card, parent, false);
        return new ItemViewHolder(view);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        LostItem item = lostItemList.get(position);

        if (!category.isEmpty() && !item.getCategory().equals(category)) {
            holder.itemView.setVisibility(View.GONE);
            return;
        }
        String imagePath = Constants.getFullImageUrl(item.getImageURL());
        Glide.with(context)
                .load(imagePath)
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.baseline_image_search_24)
                .into(holder.itemImageView);

        holder.itemNameTextView.setText(item.getItemName());
        holder.ownerNameTextView.setText(item.getOwnerName());
        holder.description.setText(item.getDescription());
        holder.location.setText(item.getLocation());
        holder.date.setText(item.getDateLost());
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, LostDetails.class);
            intent.putExtra("item", item);
            context.startActivity(intent);
        });
        boolean isOwner = item.getUserId() != null && item.getUserId().equals(currentUserId);

        if (isOwner) {
            holder.swipeActions.setVisibility(View.VISIBLE);
            holder.editButton.setOnClickListener(v -> {
                if (actionListener != null) {
                    actionListener.onEdit(holder.getAdapterPosition());
                }
            });

            holder.deleteButton.setOnClickListener(v -> {
                if (actionListener != null) {
                    actionListener.onDelete(holder.getAdapterPosition());
                }
            });
        } else {
            holder.swipeActions.setVisibility(View.GONE);
        }
        holder.itemView.setOnTouchListener((v, event) -> {
            if (lastSwipedPosition != -1 && lastSwipedPosition != position) {
                notifyItemChanged(lastSwipedPosition);
                lastSwipedPosition = -1;
            }
            return false;
        });

    }

    @Override
    public int getItemCount() {
        return lostItemList != null ? lostItemList.size() : 0;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateList(List<LostItem> newList) {
        lostItemList.clear();
        lostItemList.addAll(newList);
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        if (position >= 0 && position < lostItemList.size()) {
            lostItemList.remove(position);
            notifyItemRemoved(position);
        }
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        ImageView itemImageView;
        TextView itemNameTextView, ownerNameTextView, description, location, date;
        ImageButton deleteButton, editButton;
        LinearLayout swipeActions;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImageView = itemView.findViewById(R.id.itemImageView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            ownerNameTextView = itemView.findViewById(R.id.ownerNameTextView);
            description = itemView.findViewById(R.id.item_description);
            location = itemView.findViewById(R.id.location);
            date = itemView.findViewById(R.id.dateLost);
            deleteButton = itemView.findViewById(R.id.deleteButton_);
            swipeActions = itemView.findViewById(R.id.swipe_actions);
            editButton = itemView.findViewById(R.id.editButton);
        }
    }
}
