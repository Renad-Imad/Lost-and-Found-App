package com.shruti.findit.ui.MyProfile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.data.local.User;

public class MyProfileFragment extends Fragment {
    TextView profileName, profileEmail, profilePhone, titleName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_my_profile, container, false);

        profileName = root.findViewById(R.id.profileName);
        profileEmail = root.findViewById(R.id.profileEmail);
        profilePhone = root.findViewById(R.id.profilephone);
        titleName = root.findViewById(R.id.titlename);

        loadUserData();

        return root;
    }

    private void loadUserData() {
        Utility.getLoggedInUserAsync(requireContext(), user -> {
            if (user != null) {
                profileName.setText(user.name);
                profileEmail.setText(user.email);
                profilePhone.setText(user.phone);
                titleName.setText(user.name);
            }
        });

    }
}
