package com.shruti.findit.Admin;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shruti.findit.R;
import com.shruti.findit.data.FoundItemRepository;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.ui.DashBoard.DashBoardViewModel;
import com.shruti.findit.utils.Constants;

import java.util.ArrayList;

public class AdminPostsAdapter extends RecyclerView.Adapter<AdminPostsAdapter.ViewHolder> {

    private Context context;
    private ArrayList<DashBoardViewModel> posts;
    private OnPostClickListener clickListener;

    public AdminPostsAdapter(Context context, ArrayList<DashBoardViewModel> posts, OnPostClickListener listener) {
        this.context = context;
        this.posts = posts;
        this.clickListener = listener;
    }

    public interface OnPostClickListener {
        void onPostClick(DashBoardViewModel post);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_admin_post, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DashBoardViewModel post = posts.get(position);
        String imageUrl = Constants.getFullImageUrl(post.getImageURI());

        if (imageUrl != null && !imageUrl.startsWith("http")) {
            if (!imageUrl.contains("uploads/")) {
                imageUrl = "uploads/" + imageUrl;
            }

        }

        if (imageUrl != null) {
            Glide.with(context)
                    .load(imageUrl)
                    .placeholder(R.drawable.ic_posts)
                    .error(R.drawable.sample_img)
                    .into(holder.imageView);
        } else {
            holder.imageView.setImageResource(R.drawable.sample_img);
        }

        holder.description.setText(post.getDescription());
        holder.itemName.setText(post.getItemName());

        String tag = post.getTag();
        if ("Lost".equalsIgnoreCase(tag)) {
            holder.tag.setText("Lost");
            holder.tag.setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_dark));
            holder.ownerLabel.setText("Owner:");
            holder.ownerName.setText(post.getOwnerName());
            holder.date.setText(post.getDateLost());

            if (post.getLostItem().getIsMatched() == 1) {
                holder.verifyButton.setText("Matched");
                holder.verifyButton.setBackgroundColor(ContextCompat.getColor(context, android.R.color.darker_gray));

                holder.verifyButton.setEnabled(false);
            } else {
                holder.verifyButton.setText("Verify");
                holder.verifyButton.setEnabled(true);
            }

        } else {
            holder.tag.setText("Found");
            holder.tag.setTextColor(ContextCompat.getColor(context, android.R.color.holo_green_dark));
            holder.ownerLabel.setText("Finder:");
            holder.ownerName.setText(post.getFinderName());
            holder.date.setText(post.getDateFound());

            if (post.getFoundItem().getIsMatched() == 1) {
                holder.verifyButton.setText("Matched");
                holder.verifyButton.setBackgroundColor(ContextCompat.getColor(context, android.R.color.darker_gray));

                holder.verifyButton.setEnabled(false);
            } else {
                holder.verifyButton.setText("Verify");
                holder.verifyButton.setEnabled(true);
            }
        }


        holder.itemView.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            Intent intent = new Intent(context, DetailActivity.class);

            if (post.getTag().equalsIgnoreCase("Lost")) {
                bundle.putSerializable("lostItem", post.getLostItem());
            } else {
                bundle.putSerializable("foundItem", post.getFoundItem());
            }

            intent.putExtras(bundle);
            context.startActivity(intent);
        });


        holder.verifyButton.setOnClickListener(v -> {
            if ("Lost".equalsIgnoreCase(tag)) {
                post.getLostItem().setVerified(true);
                new Thread(() -> {
                    new LostItemRepository(context).updateItem(post.getLostItem());
                }).start();
            } else {
                post.getFoundItem().setVerified(true);
                new Thread(() -> {
                    new FoundItemRepository(context).updateItem(post.getFoundItem());
                }).start();
            }
            if ((post.getTag().equalsIgnoreCase("Lost") && post.getLostItem().getIsMatched() == 1)  &&
                    (post.getTag().equalsIgnoreCase("Found") && post.getFoundItem().getIsMatched() == 1 )) {
                holder.verifyButton.setEnabled(false);
            } else {
                holder.verifyButton.setEnabled(true);
            }

            MatchesFragment fragment = new MatchesFragment();
            Bundle bundle = new Bundle();

            if (tag.equalsIgnoreCase("Lost")) {
                bundle.putSerializable("lostItem", post.getLostItem());
            } else {
                bundle.putSerializable("foundItem", post.getFoundItem());
            }

            fragment.setArguments(bundle);
            ((androidx.fragment.app.FragmentActivity) context).getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container_admin, fragment)
                    .addToBackStack(null)
                    .commit();
        });


    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, description, ownerName, tag, date, ownerLabel;
        ImageView imageView;
        Button verifyButton;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            description = itemView.findViewById(R.id.description_admin);
            ownerName = itemView.findViewById(R.id.owner_name_admin);
            tag = itemView.findViewById(R.id.tag_admin);
            date = itemView.findViewById(R.id.date_admin);
            ownerLabel = itemView.findViewById(R.id.owner_label_admin);
            imageView = itemView.findViewById(R.id.image_view);
            verifyButton = itemView.findViewById(R.id.btn_verify);

        }
    }
}
