package com.shruti.findit.Admin;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shruti.findit.R;
import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.data.FoundItemRepository;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.ui.DashBoard.DashBoardViewModel;

import java.util.ArrayList;

public class MatchesFragment extends Fragment {

    private ProgressBar progressBar;
    private TextView noMatchesMessage;
    private RecyclerView recyclerView;
    private MatchesAdapter adapter;
    private ArrayList<DashBoardViewModel> matchList = new ArrayList<>();
    ApiService apiService ;


    private FoundItem currentFoundItem;
    private LostItem currentLostItem;

    public MatchesFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_matches, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        progressBar = view.findViewById(R.id.progressBar);
        noMatchesMessage = view.findViewById(R.id.noMatchesMessage);
        recyclerView = view.findViewById(R.id.matchesRecyclerView);


        Bundle bundle = getArguments();
        if (bundle != null) {
            if (bundle.containsKey("lostItem")) {
                currentLostItem = (LostItem) bundle.getSerializable("lostItem");
                matchWithFoundItems();
            } else if (bundle.containsKey("foundItem")) {
                currentFoundItem = (FoundItem) bundle.getSerializable("foundItem");
                matchWithLostItems();
            }
        }
    }

    private void matchWithLostItems() {
        if (currentFoundItem == null) return;

        progressBar.setVisibility(View.VISIBLE);
        LostItemRepository lostRepo = new LostItemRepository(requireContext());

        lostRepo.getAllItemsAsync(items -> {
            for (LostItem lost : items) {
                if (
                        lost.getCategory().equalsIgnoreCase(currentFoundItem.getCategory()) ||
                                lost.getItemName().toLowerCase().contains(currentFoundItem.getItemName().toLowerCase()) ||
                                lost.getLocation().equalsIgnoreCase(currentFoundItem.getLocation())
                ) {
                    matchList.add(new DashBoardViewModel(lost));
                }
            }

            updateUI();
        });
    }


    private void matchWithFoundItems() {
        if (currentLostItem == null) return;

        progressBar.setVisibility(View.VISIBLE);
        FoundItemRepository foundRepo = new FoundItemRepository(requireContext());

        foundRepo.getAllItemsAsync(items -> {
            for (FoundItem found : items) {
                if (
                        found.getCategory().equalsIgnoreCase(currentLostItem.getCategory()) ||
                                found.getItemName().toLowerCase().contains(currentLostItem.getItemName().toLowerCase()) ||
                                found.getLocation().equalsIgnoreCase(currentLostItem.getLocation())
                ) {
                    matchList.add(new DashBoardViewModel(found));
                }
            }

            updateUI();
        });
    }


    private void updateUI() {
        requireActivity().runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);

            if (matchList.isEmpty()) {
                noMatchesMessage.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
            } else {
                noMatchesMessage.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);

                adapter = new MatchesAdapter(requireContext(), matchList, currentLostItem, currentFoundItem);
                recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
                recyclerView.setAdapter(adapter);
            }
        });
    }


    private void openDetails(DashBoardViewModel post) {
        ItemDetailsFragment fragment = new ItemDetailsFragment();
        Bundle bundle = new Bundle();
        if (post.getTag().equalsIgnoreCase("Lost")) {
            bundle.putSerializable("item", post.getLostItem());
        } else {
            bundle.putSerializable("item", post.getFoundItem());
        }
        fragment.setArguments(bundle);

        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container_admin, fragment)
                .addToBackStack(null)
                .commit();
    }
}
