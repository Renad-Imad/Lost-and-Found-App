package com.shruti.findit.api.responses;


import com.google.gson.annotations.SerializedName;
import com.shruti.findit.data.local.Notification;
import java.util.List;

public class NotificationResponse {

    private String status;
    private String message;

    @SerializedName("data")
    private List<Notification> data;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public List<Notification> getData() {
        return data;
    }

}
