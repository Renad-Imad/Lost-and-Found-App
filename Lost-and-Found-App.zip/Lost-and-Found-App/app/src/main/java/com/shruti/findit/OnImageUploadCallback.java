package com.shruti.findit;

public interface OnImageUploadCallback {
    void onSuccess(String imageUrl);

    void onFailure();
}
