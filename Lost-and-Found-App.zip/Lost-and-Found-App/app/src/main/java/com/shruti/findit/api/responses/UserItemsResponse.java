package com.shruti.findit.api.responses;

import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;

import java.util.List;

public class UserItemsResponse {
    private String status;
    private List<LostItem> lost_items;
    private List<FoundItem> found_items;

    public String getStatus() {
        return status;
    }

    public List<LostItem> getLostItems() {
        return lost_items;
    }

    public List<FoundItem> getFoundItems() {
        return found_items;
    }
}