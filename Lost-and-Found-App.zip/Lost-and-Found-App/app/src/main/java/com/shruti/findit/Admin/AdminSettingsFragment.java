package com.shruti.findit.Admin;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.shruti.findit.Login;
import com.shruti.findit.R;

public class AdminSettingsFragment extends Fragment {

    private TextView adminName, adminEmail;
    private ImageView adminLogo;
    private Button logoutButton;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_settings, container, false);

        adminName = view.findViewById(R.id.admin_name);
        adminEmail = view.findViewById(R.id.admin_email);
        adminLogo = view.findViewById(R.id.admin_logo);
        logoutButton = view.findViewById(R.id.btn_logout);
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("loginPrefs", requireContext().MODE_PRIVATE);
        String name = sharedPreferences.getString("userName", "Admin");
        String email = sharedPreferences.getString("userEmail", "admin@findit.com");
        adminName.setText(name);
        adminEmail.setText(email);
        logoutButton.setOnClickListener(v -> logoutAdmin());

        return view;
    }

    private void logoutAdmin() {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("loginPrefs", requireContext().MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        Intent intent = new Intent(getActivity(), Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

        Toast.makeText(getActivity(), "Logged Out Successfully", Toast.LENGTH_SHORT).show();
    }
}
