package com.shruti.findit.api;

import com.shruti.findit.api.responses.FoundItemResponse;
import com.shruti.findit.api.responses.ImageUploadResponse;
import com.shruti.findit.api.responses.LostItemResponse;
import com.shruti.findit.api.responses.NotificationResponse;
import com.shruti.findit.api.responses.SimpleResponse;
import com.shruti.findit.api.responses.UserItemsResponse;
import com.shruti.findit.api.responses.UserResponse;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiService {

    @FormUrlEncoded
    @POST("login_user.php")
    Call<UserResponse> loginUser(
            @Field("email") String email,
            @Field("password") String password
    );
    @FormUrlEncoded
    @POST("add_matched_item.php")
    Call<SimpleResponse> addMatchedItem(
            @Field("lost_item_id") int lostItemId,
            @Field("found_item_id") int foundItemId,
            @Field("admin_id") String adminId
    );

    @FormUrlEncoded
    @POST("add_lost_item.php")
    Call<LostItemResponse> addLostItem(
            @Field("itemName") String itemName,
            @Field("category") String category,
            @Field("dateLost") String dateLost,
            @Field("timeLost") String timeLost,
            @Field("location") String location,
            @Field("description") String description,
            @Field("imageURL") String imageURL,
            @Field("userId") String userId,
            @Field("ownerName") String ownerName,
            @Field("phnum") String phnum,
            @Field("email") String email,
            @Field("tag") String tag
    );
    @FormUrlEncoded
    @POST("add_notification.php")
    Call<SimpleResponse> addNotification(
            @Field("user_id") String userId,
            @Field("title") String title,
            @Field("message") String message,
            @Field("type") String type
    );

    @FormUrlEncoded
    @POST("add_found_item.php")
    Call<SimpleResponse> addFoundItem(
            @Field("itemName") String itemName,
            @Field("category") String category,
            @Field("location") String location,
            @Field("description") String description,
            @Field("imageURL") String imageURL,
            @Field("dateFound") String dateFound,
            @Field("finderName") String finderName,
            @Field("finderId") String finderId,
            @Field("email") String email,
            @Field("phnum") String phnum,
            @Field("userId") String userId,
            @Field("tag") String tag
    );
    @FormUrlEncoded
    @POST("add_user.php")
    Call<SimpleResponse> addUser(
            @Field("userId") String userId,
            @Field("name") String name,
            @Field("email") String email,
            @Field("phone") String phone,
            @Field("password") String password,
            @Field("userType") String userType
    );
    @FormUrlEncoded
    @POST("mark_as_matched.php")
    Call<SimpleResponse> markAsMatched(
            @Field("itemId") int itemId,
            @Field("type") String type
    );

    @GET("get_lost_items.php")
    Call<LostItemResponse> getLostItems();

    @GET("get_found_items.php")
    Call<FoundItemResponse> getFoundItems();
    @GET("get_notifications.php")
    Call<NotificationResponse> getAllNotifications();

    @FormUrlEncoded
    @POST("delete_lost_item.php")
    Call<SimpleResponse> deleteLostItem(
            @Field("id") int id
    );
    @FormUrlEncoded
    @POST("delete_found_item.php")
    Call<SimpleResponse> deleteFoundItem(
            @Field("id") int id
    );
    @FormUrlEncoded
    @POST("update_found_item.php")
    Call<SimpleResponse> updateFoundItem(
            @Field("id") int id,
            @Field("itemName") String itemName,
            @Field("category") String category,
            @Field("location") String location,
            @Field("description") String description,
            @Field("imageURL") String imageURL,
            @Field("dateFound") String dateFound,
            @Field("finderName") String finderName,
            @Field("finderId") String finderId,
            @Field("email") String email,
            @Field("phnum") String phnum
    );
    @FormUrlEncoded
    @POST("update_lost_item.php")
    Call<SimpleResponse> updateLostItem(
            @Field("id") int id,
            @Field("itemName") String itemName,
            @Field("category") String category,
            @Field("dateLost") String dateLost,
            @Field("timeLost") String timeLost,
            @Field("location") String location,
            @Field("description") String description,
            @Field("imageURL") String imageURL,
            @Field("userId") String userId,
            @Field("ownerName") String ownerName,
            @Field("phnum") String phnum,
            @Field("email") String email
    );

    @GET("get_user_items.php")
    Call<UserItemsResponse> getUserItems(@Query("userId") String userId);
    @Multipart
    @POST("upload_image.php")
    Call<ImageUploadResponse> uploadImage(
            @Part MultipartBody.Part image
    );
}
