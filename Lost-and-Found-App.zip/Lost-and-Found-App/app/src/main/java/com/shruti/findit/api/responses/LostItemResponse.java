package com.shruti.findit.api.responses;

import com.shruti.findit.data.local.LostItem;

import java.util.List;

public class LostItemResponse {
    private String status;
    private List<LostItem> data;

    public String getStatus() { return status; }
    public List<LostItem> getData() { return data; }
}