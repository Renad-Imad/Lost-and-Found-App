package com.shruti.findit.data;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.FoundItemResponse;
import com.shruti.findit.api.responses.ImageUploadResponse;
import com.shruti.findit.api.responses.SimpleResponse;
import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.FoundItemDao;
import com.shruti.findit.utils.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FoundItemRepository {
    private final Context context;
    private final AppDatabase db;
    private final FoundItemDao foundItemDao;
    public final ExecutorService executorService;
    public final ApiService apiService;


    public FoundItemRepository(Context context) {
        this.context = context;
        this.db = AppDatabase.getInstance(context);
        apiService = ApiClient.getClient().create(ApiService.class);
        this.foundItemDao = db.foundItemDao();
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public void insertItem(FoundItem item, boolean hasInternet) {
        executorService.execute(() -> {
            foundItemDao.insert(item);
            if (hasInternet) {
                uploadItemToServer(item);
            }
        });
    }

    public List<FoundItem> getUnsyncedItems() {
        return foundItemDao.getUnsyncedFoundItems();
    }

    public List<FoundItem> getAllItems() {
        return foundItemDao.getAll();
    }

    public void updateItem(FoundItem item) {
        executorService.execute(() -> foundItemDao.update(item));
    }

    public void syncLocalData() {
        executorService.execute(() -> {
            List<FoundItem> unsyncedItems = foundItemDao.getUnsyncedFoundItems();
            for (FoundItem item : unsyncedItems) {
                uploadItemToServer(item);
            }
        });
    }

    public void uploadItemToServer(FoundItem item) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        Call<SimpleResponse> call = apiService.addFoundItem(
                item.getItemName(),
                item.getCategory(),
                item.getLocation(),
                item.getDescription(),
                item.getImageURI(),
                item.getDateFound(),
                item.getFinderName(),
                item.getFinderId(),
                item.getEmail(),
                item.getPhnum(),
                item.getFinderId(),
                item.getTag()
        );

        call.enqueue(new Callback<SimpleResponse>() {
            @Override
            public void onResponse(Call<SimpleResponse> call, Response<SimpleResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getStatus().equals("success")) {
                    item.setSynced(true);
                    executorService.execute(() -> foundItemDao.update(item));
                    Log.d("FoundItemRepository", "Item synced to server.");
                } else {
                    Log.e("FoundItemRepository", "Failed to sync to server.");
                }
            }

            @Override
            public void onFailure(Call<SimpleResponse> call, Throwable t) {
            }
        });
    }
    public void uploadImage(Uri imageUri, ImageUploadCallback listener) {
        if (imageUri == null) {
            listener.onFailure("Image URI is null");
            return;
        }

        String filePath = FileUtils.getPath(context, imageUri);

        if (filePath == null) {
            listener.onFailure("Unable to resolve file path from URI");
            return;
        }

        File file = new File(filePath);
        if (!file.exists()) {
            listener.onFailure("File does not exist at path: " + filePath);
            return;
        }

        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
        MultipartBody.Part imagePart = MultipartBody.Part.createFormData("image", file.getName(), requestBody);

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ImageUploadResponse> call = apiService.uploadImage(imagePart);

        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ImageUploadResponse> call, Response<ImageUploadResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getStatus().equals("success")) {
                    listener.onSuccess(response.body().getImageUrl());

                } else {
                    listener.onFailure("Failed to upload image: Server responded with error");
                }
            }

            @Override
            public void onFailure(Call<ImageUploadResponse> call, Throwable t) {
                listener.onFailure("Upload failed: " + t.getMessage());
            }
        });
    }

    public interface ImageUploadCallback {
        void onSuccess(String imageUrl);
        void onFailure(String error);
    }

    public void getAllItemsAsync(DataCallback<List<FoundItem>> callback) {
        executorService.execute(() -> {
            List<FoundItem> items = foundItemDao.getAll();
            callback.onResult(items);
        });
    }
    public void updateItem(FoundItem item, boolean hasInternet) {
        executorService.execute(() -> {
            foundItemDao.update(item);
            if (hasInternet) {
                updateItemOnServer(item);
            }
        });
    }
    private void updateItemOnServer(FoundItem item) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<SimpleResponse> call = apiService.updateFoundItem(
                item.getId(),
                item.getItemName(),
                item.getCategory(),
                item.getLocation(),
                item.getDescription(),
                item.getImageURI(),
                item.getDateFound(),
                item.getFinderName(),
                item.getFinderId(),
                item.getEmail(),
                item.getPhnum()
        );
        call.enqueue(new Callback<SimpleResponse>() {
            @Override
            public void onResponse(Call<SimpleResponse> call, Response<SimpleResponse> response) {
                if (response.isSuccessful() && response.body() != null &&
                        response.body().getStatus().equals("success")) {

                    item.setSynced(true);
                    executorService.execute(() -> foundItemDao.update(item));
                    Log.d("FoundItemRepo", "Updated on server successfully");
                } else {
                    Log.e("FoundItemRepo", "Server update failed");
                }
            }

            @Override
            public void onFailure(Call<SimpleResponse> call, Throwable t) {
                Log.e("FoundItemRepo", "Server update error: " + t.getMessage());
            }
        });
    }
    public void deleteItem(FoundItem item, DeletionFoundCallback callback) {
        executorService.execute(() -> {
            try {
                foundItemDao.deleteById(item.getId());


                if (item.isSynced()) {
                    deleteFromServer(item.getId(), callback);
                } else {
                    callback.onSuccess();
                }
            } catch (Exception e) {
                callback.onError(e.getMessage());
            }
        });
    }

    private void deleteFromServer(int itemId, DeletionFoundCallback callback) {
        apiService.deleteFoundItem(itemId).enqueue(new Callback<SimpleResponse>() {
            @Override
            public void onResponse(Call<SimpleResponse> call, Response<SimpleResponse> response) {
                if (response.isSuccessful() && response.body() != null &&
                        response.body().getStatus().equals("success")) {
                    callback.onSuccess();
                } else {
                    callback.onError("Server deletion failed");
                }
            }

            @Override
            public void onFailure(Call<SimpleResponse> call, Throwable t) {
                callback.onError("Network error: " + t.getMessage());
            }
        });
    }
    public interface DataCallback<T> {
        void onResult(T result);
    }

    public void fetchFromServer(OnResultListener<List<FoundItem>> listener) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        apiService.getFoundItems().enqueue(new Callback<FoundItemResponse>() {
            @Override
            public void onResponse(Call<FoundItemResponse> call, Response<FoundItemResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getStatus().equals("success")) {
                    List<FoundItem> items = response.body().getData();
                    executorService.execute(() -> {
                        foundItemDao.clearAll();
                        for (FoundItem item : items) {
                            item.setSynced(true);
                            foundItemDao.insert(item);
                        }
                        listener.onResult(items);
                    });
                } else {
                    listener.onResult(new ArrayList<>());
                }
            }

            @Override
            public void onFailure(Call<FoundItemResponse> call, Throwable t) {
                listener.onResult(new ArrayList<>());
            }
        });
    }

    public void markAsMatched(int itemId, OnResultListener<Boolean> callback) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<SimpleResponse> call = apiService.markAsMatched(itemId, "Found");

        call.enqueue(new Callback<SimpleResponse>() {
            @Override
            public void onResponse(Call<SimpleResponse> call, Response<SimpleResponse> response) {
                if (response.isSuccessful() && response.body() != null && "success".equals(response.body().getStatus())) {
                    executorService.execute(() -> {
                        FoundItem item = foundItemDao.getItemById(itemId);
                        if (item != null) {
                            item.setIsMatched(1);
                            foundItemDao.update(item);
                        }
                    });
                    callback.onResult(true);
                } else {
                    callback.onResult(false);
                }
            }

            @Override
            public void onFailure(Call<SimpleResponse> call, Throwable t) {
                callback.onResult(false);
            }
        });
    }
    public interface DeletionFoundCallback {
        void onSuccess();
        void onError(String error);
    }
}
