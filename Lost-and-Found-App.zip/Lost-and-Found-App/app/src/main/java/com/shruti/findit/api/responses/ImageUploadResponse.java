package com.shruti.findit.api.responses;

import com.google.gson.annotations.SerializedName;

public class ImageUploadResponse {

    @SerializedName("status")
    private String status;

    @SerializedName("message")
    private String message;

    @SerializedName("image_url")
    private String imageUrl;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
