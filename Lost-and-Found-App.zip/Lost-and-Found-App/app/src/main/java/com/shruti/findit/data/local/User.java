package com.shruti.findit.data.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "users",
        indices = {@Index(value = "email", unique = true)}
)
public class User {
    @PrimaryKey(autoGenerate = false)
    @NonNull
    public String userId;

    public String name;
    public String email;
    public String phone;
    public String password;
    public String userType;
    public boolean isSynced;
}