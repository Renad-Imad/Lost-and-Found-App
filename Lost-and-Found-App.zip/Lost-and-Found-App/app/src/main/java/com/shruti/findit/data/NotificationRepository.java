package com.shruti.findit.data;

import android.content.Context;

import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.Notification;
import com.shruti.findit.data.local.NotificationDao;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NotificationRepository {
    private final NotificationDao dao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public NotificationRepository(Context context) {
        dao = AppDatabase.getInstance(context).notificationDao();
    }

    public void insert(Notification notification) {
        executor.execute(() -> dao.insert(notification));
    }

    public void getAll(FoundItemRepository.DataCallback<List<Notification>> callback) {
        executor.execute(() -> callback.onResult(dao.getAll()));
    }

    public void markAsRead(int id) {
        executor.execute(() -> dao.markAsRead(id));
    }

    public void clearAll() {
        executor.execute(dao::clearAll);
    }

}
