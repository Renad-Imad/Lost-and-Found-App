package com.shruti.findit.api.responses;

import com.shruti.findit.data.local.FoundItem;

import java.util.List;

public class FoundItemResponse {
    private String status;
    private List<FoundItem> data;

    public String getStatus() { return status; }
    public List<FoundItem> getData() { return data; }
}