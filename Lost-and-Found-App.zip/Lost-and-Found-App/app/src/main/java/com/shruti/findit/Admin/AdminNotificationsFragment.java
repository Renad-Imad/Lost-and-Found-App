package com.shruti.findit.Admin;


import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.shruti.findit.R;
import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.NotificationResponse;
import com.shruti.findit.api.responses.SimpleResponse;
import com.shruti.findit.data.NotificationRepository;
import com.shruti.findit.data.local.Notification;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminNotificationsFragment extends Fragment {

    private RecyclerView recyclerView;
    private NotificationAdapter adapter;
    private ArrayList<Notification> notifications = new ArrayList<>();
    private NotificationRepository notificationRepo;
    private ApiService apiService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_notifications, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        recyclerView = view.findViewById(R.id.notificationsRecyclerView);
        view.findViewById(R.id.btnAddNotification).setOnClickListener(v -> showAddDialog());

        notificationRepo = new NotificationRepository(requireContext());
        apiService = ApiClient.getClient().create(ApiService.class);

        adapter = new NotificationAdapter(notifications);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        fetchNotificationsFromServer();
    }

    private void fetchNotificationsFromServer() {
        apiService.getAllNotifications().enqueue(new Callback<NotificationResponse>() {
            @Override
            public void onResponse(Call<NotificationResponse> call, Response<NotificationResponse> response) {

                Log.e("NOTIFY", "Response code: " + response.code());
                Log.e("NOTIFY", "Response body: " + new Gson().toJson(response.body()));                if (response.isSuccessful() && response.body() != null &&
                        "success".equals(response.body().getStatus())) {

                    notifications.clear();
                    notifications.addAll(response.body().getData());
                    adapter.notifyDataSetChanged();
                    for (Notification notification : response.body().getData()) {
                        notificationRepo.insert(notification);
                    }
                }
            }

            @Override
            public void onFailure(Call<NotificationResponse> call, Throwable t) {
                Toast.makeText(getContext(), "Failed to load notifications", Toast.LENGTH_SHORT).show();
                notificationRepo.getAll(result -> {
                    notifications.clear();
                    notifications.addAll(result);
                    requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
                });

            }
        });
    }

    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add Notification");

        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_notification, null);
        EditText titleInput = view.findViewById(R.id.notificationTitle);
        EditText messageInput = view.findViewById(R.id.notificationMessage);

        builder.setView(view);
        builder.setPositiveButton("Send", (dialog, which) -> {
            String title = titleInput.getText().toString().trim();
            String message = messageInput.getText().toString().trim();

            if (!title.isEmpty() && !message.isEmpty()) {
                apiService.addNotification("all", title, message, "tip").enqueue(new Callback<SimpleResponse>() {
                    @Override
                    public void onResponse(Call<SimpleResponse> call, Response<SimpleResponse> response) {
                        if (response.isSuccessful() && response.body() != null &&
                                "success".equals(response.body().getStatus())) {

                            Toast.makeText(getContext(), "Notification sent successfully", Toast.LENGTH_SHORT).show();
                            Notification newNotification = new Notification();
                            newNotification.setTitle(title);
                            newNotification.setMessage(message);
                            newNotification.setType("tip");
                            notificationRepo.insert(newNotification);
                            fetchNotificationsFromServer();
                        }
                    }

                    @Override
                    public void onFailure(Call<SimpleResponse> call, Throwable t) {
                        Toast.makeText(getContext(), "Failed to send notification", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
