package com.shruti.findit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.SimpleResponse;
import com.shruti.findit.data.local.AppDatabase;
import com.shruti.findit.data.local.User;
import com.shruti.findit.utils.NetworkUtils;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Register extends AppCompatActivity {

    EditText signupName, signupPhone, signupEmail, signupPassword;
    TextView loginRedirectText;
    Button signupButton;
    RadioGroup userTypeGroup;

    AppDatabase localDb;
    ExecutorService executorService;
    ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        signupName = findViewById(R.id.signup_name);
        signupEmail = findViewById(R.id.signup_email);
        signupPhone = findViewById(R.id.signup_phone);
        signupPassword = findViewById(R.id.signup_password);
        loginRedirectText = findViewById(R.id.loginRedirectText);
        signupButton = findViewById(R.id.signup_button);
        userTypeGroup = findViewById(R.id.userTypeGroup);

        localDb = AppDatabase.getInstance(this);
        executorService = Executors.newSingleThreadExecutor();
        apiService = ApiClient.getClient().create(ApiService.class);

        signupButton.setOnClickListener(view -> {
            String name = signupName.getText().toString().trim();
            String email = signupEmail.getText().toString().trim();
            String phone = signupPhone.getText().toString().trim();
            String password = signupPassword.getText().toString().trim();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(password)) {
                Toast.makeText(Register.this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
                return;
            }

            int selectedId = userTypeGroup.getCheckedRadioButtonId();
            RadioButton selectedRadioButton = findViewById(selectedId);
            String userType = selectedRadioButton.getText().toString();
            String userId = UUID.randomUUID().toString();
            User newUser = new User();
            newUser.userId = userId;
            newUser.name = name;
            newUser.email = email;
            newUser.phone = phone;
            newUser.password = password;
            newUser.userType = userType;
            newUser.isSynced = false;
            executorService.execute(() -> localDb.userDao().insert(newUser));
            if (NetworkUtils.isNetworkAvailable(Register.this)) {
                syncUserToServer(newUser);
            } else {
                Toast.makeText(Register.this, "User saved locally. Will sync when online.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Register.this, Login.class));
                finish();
            }
        });

        loginRedirectText.setOnClickListener(view -> startActivity(new Intent(Register.this, Login.class)));
    }

    private void syncUserToServer(User user) {
        Call<SimpleResponse> call = apiService.addUser(
                user.userId,
                user.name,
                user.email,
                user.phone,
                user.password,
                user.userType
        );

        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<SimpleResponse> call, @NonNull Response<SimpleResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getStatus().equals("success")) {
                    user.isSynced = true;
                    executorService.execute(() -> localDb.userDao().update(user));
                    Toast.makeText(Register.this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Register.this, "Saved locally. Sync failed: " + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

                startActivity(new Intent(Register.this, Login.class));
                finish();
            }

            @Override
            public void onFailure(@NonNull Call<SimpleResponse> call, @NonNull Throwable t) {
                Toast.makeText(Register.this, "Saved locally. Sync error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("Register", "Sync failed", t);
                startActivity(new Intent(Register.this, Login.class));
                finish();
            }
        });
    }
}
