package com.shruti.findit.Admin;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shruti.findit.R;
import com.shruti.findit.data.FoundItemRepository;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.ui.DashBoard.DashBoardViewModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AdminPostsFragment extends Fragment {

    private RecyclerView recyclerView;
    private ArrayList<DashBoardViewModel> postList;
    private AdminPostsAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_posts, container, false);

        recyclerView = view.findViewById(R.id.admin_posts_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        postList = new ArrayList<>();
        adapter = new AdminPostsAdapter(requireContext(), postList, post -> {
            openDetails(post);
        });

        recyclerView.setAdapter(adapter);

        fetchPostsFromServer();

        return view;
    }

    @SuppressLint("NotifyDataSetChanged")
    private void fetchPostsFromLocalDatabase() {
        LostItemRepository lostRepo = new LostItemRepository(requireContext());
        FoundItemRepository foundRepo = new FoundItemRepository(requireContext());

        new Thread(() -> {
            List<LostItem> lostItems = lostRepo.getAllItems();
            List<FoundItem> foundItems = foundRepo.getAllItems();

            ArrayList<DashBoardViewModel> tempList = new ArrayList<>();

            for (LostItem lost : lostItems) {
                tempList.add(new DashBoardViewModel(lost));
            }
            for (FoundItem found : foundItems) {
                tempList.add(new DashBoardViewModel(found));
            }

            Collections.sort(tempList, (o1, o2) -> {
                String date1 = o1.getTag().equalsIgnoreCase("Lost") ? o1.getDateLost() : o1.getDateFound();
                String date2 = o2.getTag().equalsIgnoreCase("Lost") ? o2.getDateLost() : o2.getDateFound();

                if (date1 == null && date2 == null) return 0;
                if (date1 == null) return 1;
                if (date2 == null) return -1;

                return date2.compareTo(date1);
            });

            requireActivity().runOnUiThread(() -> {
                postList.clear();
                postList.addAll(tempList);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }
    private void fetchPostsFromServer() {
        LostItemRepository lostRepo = new LostItemRepository(requireContext());
        FoundItemRepository foundRepo = new FoundItemRepository(requireContext());

        postList.clear();

        lostRepo.fetchFromServer(lostItems -> {
            for (LostItem lost : lostItems) {
                postList.add(new DashBoardViewModel(lost));
            }

            foundRepo.fetchFromServer(foundItems -> {
                for (FoundItem found : foundItems) {
                    postList.add(new DashBoardViewModel(found));
                }
                Collections.sort(postList, (o1, o2) -> {
                    String date1 = o1.getTag().equalsIgnoreCase("Lost") ? o1.getDateLost() : o1.getDateFound();
                    String date2 = o2.getTag().equalsIgnoreCase("Lost") ? o2.getDateLost() : o2.getDateFound();

                    if (date1 == null && date2 == null) return 0;
                    if (date1 == null) return 1;
                    if (date2 == null) return -1;

                    return date2.compareTo(date1);
                });

                requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
            });
        });
    }


    private void openDetails(DashBoardViewModel post) {
        ItemDetailsFragment fragment = new ItemDetailsFragment();
        Bundle bundle = new Bundle();
        if (post.getTag().equalsIgnoreCase("Lost")) {
            bundle.putSerializable("item", post.getLostItem());
        } else {
            bundle.putSerializable("item", post.getFoundItem());
        }
        fragment.setArguments(bundle);

        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container_admin, fragment)
                .addToBackStack(null)
                .commit();
    }

}
