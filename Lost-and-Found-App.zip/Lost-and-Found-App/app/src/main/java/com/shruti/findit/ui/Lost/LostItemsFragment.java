package com.shruti.findit.ui.Lost;

import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import com.shruti.findit.MapActivity;
import com.shruti.findit.OnItemAddedListener;
import com.shruti.findit.R;
import com.shruti.findit.Utility;
import com.shruti.findit.api.ApiClient;
import com.shruti.findit.api.ApiService;
import com.shruti.findit.api.responses.ImageUploadResponse;
import com.shruti.findit.data.LostItemRepository;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.utils.Constants;
import com.shruti.findit.utils.FileUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LostItemsFragment extends DialogFragment {

    private LostItemRepository lostItemRepository;
    private EditText itemNameField, description, location;
    private TextView dateEdit, timeEdit;
    private Spinner categorySpinner;
    private ImageView image,locationIcon;
    private Button upload, submitBtn;
    private Uri imageUri;
    private String date, time;
    private LostItem editingItem = null;
    private OnItemAddedListener itemAddedListener;
    private final int REQ_CODE = 1000;

    public void setOnItemAddedListener(OnItemAddedListener listener) {
        this.itemAddedListener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_lost_items, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        lostItemRepository = new LostItemRepository(requireContext());

        itemNameField = view.findViewById(R.id.item_name_edittext);
        description = view.findViewById(R.id.description);
        location = view.findViewById(R.id.location_lost);
        dateEdit = view.findViewById(R.id.selectedDateEditText);
        timeEdit = view.findViewById(R.id.selectedTimeEditText);
        image = view.findViewById(R.id.selectedImageView);
        upload = view.findViewById(R.id.uploadImageButton);
        submitBtn = view.findViewById(R.id.submit_button);
        locationIcon = view.findViewById(R.id.location_icon);
        categorySpinner = view.findViewById(R.id.categorySpinner);
        locationIcon.setOnClickListener(v -> startActivityForResult(new Intent(getActivity(), MapActivity.class), 200));
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(requireContext(),
                R.array.categories_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        view.findViewById(R.id.datePickerButton).setOnClickListener(v -> showDatePicker());
        view.findViewById(R.id.timePickerButton).setOnClickListener(v -> showTimePicker());

        upload.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_MEDIA_IMAGES)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 101);
                    return;
                }
            } else {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
                    return;
                }
            }

            Intent iGallery = new Intent(Intent.ACTION_PICK);
            iGallery.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(iGallery, REQ_CODE);
        });
        if (getArguments() != null && getArguments().containsKey("item")) {
            editingItem = (LostItem) getArguments().getSerializable("item");
            if (editingItem != null) {
                itemNameField.setText(editingItem.getItemName());
                description.setText(editingItem.getDescription());
                location.setText(editingItem.getLocation());
                date = editingItem.getDateLost();
                time = editingItem.getTimeLost();
                dateEdit.setText(date);
                timeEdit.setText(time);
                String imagePath =Constants.getFullImageUrl(editingItem.getImageURL());

                if (imagePath != null) {
                    imageUri = Uri.parse(imagePath);
                    image.setImageURI(imageUri);
                    upload.setText("Image Selected");
                }

                int catPos = adapter.getPosition(editingItem.getCategory());
                if (catPos >= 0) categorySpinner.setSelection(catPos);
            }
        }

        submitBtn.setOnClickListener(v -> saveOrUpdateItem());
    }
    private void openGallery() {
        Intent pick = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pick, REQ_CODE);
    }

    private boolean isSaving = false;

    private void saveOrUpdateItem() {
        if (isSaving) return;

        String name = itemNameField.getText().toString().trim();
        String desc = description.getText().toString().trim();
        String loc = location.getText().toString().trim();
        String cat = categorySpinner.getSelectedItem().toString();

        boolean isNewImage = imageUri != null && !imageUri.toString().startsWith("http");

        if (name.isEmpty() || desc.isEmpty() || loc.isEmpty() || date == null || time == null || cat.equals("Select Category")) {
            Utility.showToast(getContext(), "Please fill all fields");
            return;
        }

        if (!isNewImage && editingItem == null) {
            Utility.showToast(getContext(), "Please upload an image");
            return;
        }

        LostItem item = editingItem != null ? editingItem : new LostItem();

        Utility.getLoggedInUserAsync(requireContext(), user -> {
            if (user == null) {
                Utility.showToast(getContext(), "User not logged in");
                return;
            }

            item.setItemName(name);
            item.setCategory(cat);
            item.setDateLost(formatDate(date));
            item.setTimeLost(time);
            item.setLocation(loc);
            item.setDescription(desc);
            item.setUserId(user.userId);
            item.setOwnerName(user.name);
            item.setPhnum(user.phone);
            item.setEmail(user.email);
            item.setTag("Lost");

            if (isNewImage) {
                if (isConnected()) {
                    uploadImageToServer(imageUri, new OnImageUploadListener() {
                        @Override
                        public void onSuccess(String imageUrl) {
                            item.setImageURL(imageUrl);
                            item.setSynced(false);
                            finishSave(item);
                        }

                        @Override
                        public void onFailure(String error) {
                            Utility.showToast(getContext(), "Upload failed: " + error);
                            // حتى لو فشل، نحفظ الصورة كـ local path
                            item.setImageURL(imageUri.toString());
                            item.setSynced(false);
                            finishSave(item);
                        }
                    });
                } else {
                    // بدون إنترنت: نخزن الصورة كمسار محلي فقط
                    item.setImageURL(imageUri.toString());
                    item.setSynced(false);
                    finishSave(item);
                }
            } else {
                String imagePath = editingItem != null ? editingItem.getImageURL() : "";
                item.setImageURL(imagePath);
                finishSave(item);
            }
        });
    }

    private void finishSave(LostItem item) {
        if (isSaving) return;
        isSaving = true;

        if (editingItem != null) {
            lostItemRepository.updateItem(item);
            if (isConnected()) lostItemRepository.updateItemRemote(item);
            Toast.makeText(getContext(), "Item updated", Toast.LENGTH_SHORT).show();
        } else {
            lostItemRepository.insertItem(item, isConnected());
            Toast.makeText(getContext(), "Item added", Toast.LENGTH_SHORT).show();
        }

        if (itemAddedListener != null) itemAddedListener.onItemAdded();
        dismiss();
    }

    private void uploadImageToServer(Uri uri, OnImageUploadListener listener) {
        String path = FileUtils.getPath(requireContext(), uri);
        if (path == null || !new File(path).exists()) {
            listener.onFailure("Invalid file");
            return;
        }

        File file = new File(path);
        RequestBody req = RequestBody.create(MediaType.parse("image/*"), file);
        MultipartBody.Part part = MultipartBody.Part.createFormData("image", file.getName(), req);

        ApiClient.getClient().create(ApiService.class).uploadImage(part).enqueue(new Callback<>() {
            @Override public void onResponse(Call<ImageUploadResponse> call, Response<ImageUploadResponse> res) {
                if (res.isSuccessful() && res.body() != null && "success".equals(res.body().getStatus())) {
                    String imagePath = Constants.getFullImageUrl(res.body().getImageUrl());
                    listener.onSuccess(imagePath);
                } else {
                    listener.onFailure("Server error");
                }
            }

            @Override public void onFailure(Call<ImageUploadResponse> call, Throwable t) {
                listener.onFailure(t.getMessage());
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        Network active = cm.getActiveNetwork();
        NetworkCapabilities cap = cm.getNetworkCapabilities(active);
        return cap != null && (cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || cap.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(requireContext(), (view, year, month, day) -> {
            date = day + "/" + (month + 1) + "/" + year;
            dateEdit.setText(date);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker() {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(requireContext(), (view, hourOfDay, minute) -> {
            time = String.format(Locale.getDefault(), "%02d:%02d:00", hourOfDay, minute);
            timeEdit.setText(time);
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();

    }

    private String formatDate(String inputDate) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(
                    new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(inputDate)
            );
        } catch (Exception e) {
            return "";
        }
    }


    @SuppressLint("SetTextI18n")
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQ_CODE) {
                imageUri = data.getData();
                image.setImageURI(imageUri);
                upload.setText("Image Selected");
            } else if (requestCode == 200) {
                double latitude = data.getDoubleExtra("latitude", 0);
                double longitude = data.getDoubleExtra("longitude", 0);
                location.setText("Lat: " + latitude + ", Lng: " + longitude);
            }
        }
    }
    interface OnImageUploadListener {
        void onSuccess(String imageUrl);
        void onFailure(String error);
    }
}
