package com.shruti.findit.data.local;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "matched_items")
public class MatchedItem {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public int lostItemId;
    public int foundItemId;
    public String adminId;

    public String matchedDate;

    public boolean isSynced = false;
}
