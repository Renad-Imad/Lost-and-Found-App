package com.shruti.findit.Admin;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.shruti.findit.R;
import com.shruti.findit.data.local.FoundItem;
import com.shruti.findit.data.local.LostItem;
import com.shruti.findit.utils.Constants;

public class DetailActivity extends AppCompatActivity {

    private TextView title, description, category, ownerOrFinder, date, location, email, phone;
    private ImageView imageView;
    private boolean isLost = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        initViews();

        if (getIntent().hasExtra("lostItem")) {
            LostItem lostItem = (LostItem) getIntent().getSerializableExtra("lostItem");
            isLost = true;
            bindLostItem(lostItem);
        } else if (getIntent().hasExtra("foundItem")) {
            FoundItem foundItem = (FoundItem) getIntent().getSerializableExtra("foundItem");
            bindFoundItem(foundItem);
        }
    }

    private void initViews() {
        title = findViewById(R.id.item_name_detail);
        description = findViewById(R.id.item_description_detail);
        category = findViewById(R.id.item_category_detail);
        ownerOrFinder = findViewById(R.id.item_owner_finder_detail);
        date = findViewById(R.id.item_date_detail);
        location = findViewById(R.id.item_location_detail);
        email = findViewById(R.id.item_email_detail);
        phone = findViewById(R.id.item_phone_detail);
        imageView = findViewById(R.id.item_image_detail);
    }

    private void bindLostItem(LostItem item) {
        title.setText(item.getItemName());
        description.setText(item.getDescription());
        category.setText(item.getCategory());
        ownerOrFinder.setText("Owner Name: " + item.getOwnerName());
        date.setText("Date Lost: " + item.getDateLost());
        location.setText("Location : " + item.getLocation());
        email.setText("Email : " + item.getEmail());
        phone.setText("Phone Number: " + item.getPhnum());
        String imagePath = Constants.getFullImageUrl(item.getImageURL());
        loadImage(imagePath);
    }

    private void bindFoundItem(FoundItem item) {
        title.setText(item.getItemName());
        description.setText(item.getDescription());
        category.setText(item.getCategory());
        ownerOrFinder.setText("Finder Name:  " + item.getFinderName());
        date.setText("Date Found: " + item.getDateFound());
        location.setText("Location:  " + item.getLocation());
        email.setText("Email: " + item.getEmail());
        phone.setText("Phone : " + item.getPhnum());
        String imagePath = Constants.getFullImageUrl(item.getImageURI());
        loadImage(imagePath);
    }

    private void loadImage(String imageUrl) {

        Glide.with(this)
                .load(imageUrl)
                .error(R.drawable.sample_img)
                .into(imageView);
    }
}
