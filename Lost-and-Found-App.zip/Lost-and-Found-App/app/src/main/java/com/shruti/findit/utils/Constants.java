package com.shruti.findit.utils;

public class Constants {
    public static final String BASE_URL = "http://findit.ddns.net";

    public static String getFullImageUrl(String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) return "";
        return imagePath.startsWith("http") ? imagePath : BASE_URL + "uploads/" + imagePath;
    }

}
